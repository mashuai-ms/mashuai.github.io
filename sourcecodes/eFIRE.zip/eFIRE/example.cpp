#include "eFIRE.h"
using namespace std;

int main() {
	string subjNotShareFN = "subjrelscore.txt";			// S-S domain constraint: two relations can not share subjects
	string objNotShareFN = "relobjscore.txt";			// O-O domain constraint: two relations can not share objects
	string subjObjNotShareFN = "subjrelobjscore.txt";	// S-O domain constraint: subject of relation 1 can not be object of relation 2
	string subjUniqueFN = "objreluniquescore.txt";		// O uniqueness constraint: given relation r and object o, there can only be one subject among all candidates
	string objUniqueFN = "subjreluniquescore.txt";		// S uniqueness constraint: given relation r and subject s, there can only be one object among all candidates
	string corpusFN = "corpus.txt";						// The mentions preprocessed by a sentence level extractor

	string dir = "../SampleData/";				// The directory of the input and output data
	int mentC = 53162;									// The number of mentions in corpusFN
	int relC = 52;										// The number of different relations in corpusFN
	int eC = 12021;										// The number of different entities in corpusFN

	double ThreDomainNum = 0.1;							// The relations whose scores are lower than the threshold will be to have domain constraints
	double ThreUniquenessNum = 0.8;						// The relations whose scores are higher than the threshold will be to have uniqueness constraints
	double ThreConfBaseNum = 0.05;						// The base number of aggregating function for obtaining S-O redundancies (formula (2) in the paper)

	Inference infer(dir + corpusFN, mentC, relC, subjNotShareFN, objNotShareFN, subjObjNotShareFN, subjUniqueFN, objUniqueFN, 
		dir, eC, ThreDomainNum, ThreUniquenessNum, ThreConfBaseNum);
	
	double threEnt = 0.8;								// Threshold of entropy: minimum entropy to distinguish easy decisions from hard ones
	int numTotThre = 3;									// Threshold of k: top-k candidate relations in each mention which could be considered by ILP 
	double scrTotThre = 0.1;							// Threshold of s: candidate relations with scores no less than s which could be considered by ILP 

	infer.setParaStep1End(threEnt);						// Set the threshold to distinguish easy decisions from hard ones
	infer.setParaOptTriad(numTotThre, scrTotThre);		// Set the thresholds for chosing candidates from mentions 

	int frameworkModel = 0;								// Different model choosing: 0 eFIRE, 1 eFIRE-1S, 2 eFIRE-2S, 3 baseline
	infer.run(frameworkModel);							// Run the model

	cin.get();
	return EXIT_SUCCESS;
}
