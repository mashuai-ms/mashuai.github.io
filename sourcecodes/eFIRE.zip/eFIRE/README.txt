============================================================================
Usage
============================================================================
The following examples have been tested in MS Visual Studio 2012 in x64 platform under Release mode. Read example.cpp to see the code in more detail.


Initialization: load data of mentions and constraints
 ---------------------------------------------------------------------------

    `Inference infer(dir + corpusFN, mentC, relC, subjNotShareFN, objNotShareFN, subjObjNotShareFN, subjUniqueFN, objUniqueFN, dir, eC, ThreDomainNum, ThreUniquenessNum, ThreConfBaseNum);`

	* dir: the directory of the input and output data
	* corpusFN: the file name of the mentions preprocessed by a sentence level extractor
	* mentC: the number of mentions in the corpus
	* relC: the number of different relations in the corpus
	* subjNotShareFN: the file name of S-S domain constraint. Two relations can not share subjects
	* objNotShareFN: the file name of O-O domain constraint. Two relations can not share objects
	* subjObjNotShareFN: the file name of S-O domain constraint. Subject of relation 1 can not be object of relation 2
	* subjUniqueFN: the file name of O uniqueness constraint. Given relation r and object o, there can only be one subject among all candidates
	* objUniqueFN: the file name of S uniqueness constraint. Given relation r and subject s, there can only be one object among all candidates
	* eC: the number of different entities in the corpus
	* ThreDomainNum: the relations whose scores are lower than this threshold will be to have domain constraints
	* ThreUniquenessNum: the relations whose scores are higher than this threshold will be to have uniqueness constraints
	* ThreConfBaseNum: the base number of aggregating function for using S-O redundancies (formula (2) in the paper)


Parameters setting: set thresholds of framework
---------------------------------------------------------------------------

	`infer.setParaStep1End(threEnt);`
	`infer.setParaOptTriad(numTotThre, scrTotThre);`

	* threEnt: threshold of entropy. Minimum entropy to distinguish easy decisions from hard ones
	* numTotThre: threshold of k. Top-k candidate relations in each mention which could be considered by ILP
	* scrTotThre: threshold of s. Candidate relations with scores no less than s which could be considered by ILP 


Running: extract relations
---------------------------------------------------------------------------

	`infer.run(frameworkModel);`

	* frameworkModel: Different model choice. 0 is eFIRE, 1 is eFIRE-1S, 2 is eFIRE-2S


============================================================================
Data Format
============================================================================


Corpus
---------------------------------------------------------------------------
	* Each line consists of various elements "r1:c1 ... rn:cn s r o"
	* r1:c1 ... rn:cn: all candidate relations and their scores preprocessed by a sentence level extractor in descending order (n is the number of different relations in the corpus)
	* s & r & o: the real relation r between the subject s and the object o of this mention.


Domain constraint
---------------------------------------------------------------------------
	* Each line consists of three elements "r1 r2 c"
	* r1 & r2 & c: the score c represents the tendency that relation r1 and relation r2 hold the domain constraint


Uniqueness constraint
---------------------------------------------------------------------------
	* Each line consists of two elements "r c"
	* r & c: the score c represents the tendency that relation r hold the uniqueness constraint


Precision-Recall curve
---------------------------------------------------------------------------
	* Each line consists of six elements "n d t p r f1"
	* n & d: the number n of right decisions and the number d of decisions made
	* t: the total number of <subject, real relation, object> in the ground-truth
	* p & r & f1: precision, recall, and F1-score


Right and wrong decisions set
---------------------------------------------------------------------------
	* Each line consists of three elements "s, o, r"
	* s & o: the subject and the object
	* r: relation


============================================================================
Deployment
============================================================================
All the necessary files are in the directory "eFIRE". The actual directory is denoted as <EFIREDIR>.

The deployment of eFIRE for MS Visual Studio 2012 in x64 platform under Release mode is as follows:

1. Change the VS project to x64 & Release mode
2. Configuration Properties -> VC++ directories -> Include Directories, add the directories:
	1. <EFIREDIR>\include
3. Configuration Properties -> VC++ directories -> Library Directories, add the directories:
	1. <EFIREDIR>\lib
4. Configuration Properties -> Linker -> Input -> Additional Dependencies, add the files: 
	1. eFIRE.lib
5. Copy the file eFIRE.dll to the same directory as the executable file generated by VS


============================================================================
ILP tool
============================================================================
We use the IBM ILOG CPLEX 12.6.3.0 for ILP. Before deployment, you need to make sure that the tool has been installed correctly. For brevity, the installation root directory is denoted as <CPLEXDIR>.

The deployment of CPLEX for MS Visual Studio 2012 in x64 platform under Release mode is as follows:

1. Change the VS project to x64 & Release mode
2. Configuration Properties -> C/C++ -> General -> Additional Include Directories, add the directories:
	1. <CPLEXDIR>\cplex\include
	2. <CPLEXDIR>\concert\include
3. Configuration Properties -> C/C++ -> Preprocessor: 
	1. Add IL_STD to the Preprocessor Definitions field
4. Configuration Properties -> C/C++ -> Code Generation: 
	1. Set Runtime Library to Multi-threaded (/MD)
5. Configuration Properties -> Linker -> General -> Additional Library Directories, Add the directories:
	1. <CPLEXDIR>\cplex\lib\x64\_windows\_vs2012\stat_mda
	2. <CPLEXDIR>\concert\lib\x64\_windows\_vs2012\stat_mda
6. Configuration Properties -> Linker -> Input -> Additional Dependencies, add the files: 
	1. cplex1263.lib
	2. ilocplex.lib
	3. concert.lib
7. Copy the file cplex1263.dll to the same directory as the executable file generated by VS

If you want to learn more about CPLEX, please click https://www.ibm.com/analytics/cplex-optimizer.


============================================================================
Baseline
============================================================================
* Liwei Chen, Yansong Feng, Songfang Huang, Yong Qin, and Dongyan Zhao. 2014. Encoding relation requirements for relation extraction via joint inference. In Proceedings of the 52nd Annual Meeting of the Association for Computational Linguistics, ACL 2014, June 22-27, 2014, Baltimore, MD, USA.
* Yankai Lin, Shiqi Shen, Zhiyuan Liu, Huanbo Luan, and Maosong Sun. 2016. Neural relation extraction with selective attention over instances. In Proceedings of the 54th Annual Meeting of the Association for Computational Linguistics, ACL 2016, August 7-12, 2016, Berlin, Germany.

