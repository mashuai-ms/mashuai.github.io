#pragma once
 
#ifdef MATH_EXPORTS
#define MATH_API __declspec(dllexport)
#else
#define MATH_API __declspec(dllimport)
#endif

#ifndef _INFERENCE_H
#define _INFERENCE_H

#include "BasicDS.h"
#include <string>
#include <set>
#include <vector>
#include <hash_map>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <math.h>
#include <ilcplex/ilocplex.h>
ILOSTLBEGIN

using namespace std;

class MATH_API Inference
{
public:
	Inference(const string &, const int, const int, const string &, const string &, const string &, const string &, const string &, 
		const string & i_dir, const int i_eC, const double, const double, const double);
	~Inference();
	void setParaStep1End(const double);				// Threshold for Step1 ending
	void setParaOptTriad(const int, const double);	// Threshold for chosing elements from records 
	void run(const int &);							// The main process of eFIRE

private:
	Mention ment;									// Mentions
	Constraint cons;								// Constraints
	int mentC, relC;								// Mention count & Relation count
	double threEnt;									// Threshold of entropy: minimum entropy which could be predicted by stage 1 
	int numTotThre;									// Threshold of k: predicted as dominant relation in at least k mentions
	double scrTotThre;								// Threshold of score: predicted as dominant relation in at least score
	int nPred1;										// The number of decision in the stage 1
	IIDSD * hcc;									// High confidence candidates, max-heap
	int hccSize;									// Size of max-heap
	map<IntPair, int> eprel2idx; 					// Map of <entity pair, relation>
	int idxNA;										// Index of NA
	vector<GrndTrthTriad> decision;					// Result set 
	vector<double> decScore;						// Confidence set of decisions
	vector<IIDSD> subjRel2conf, objRel2conf;		// Confidence of <s, r> & Confidence of <o, r>

	void generateHCC();								// generate high confidence candidates
	void earlyDecision();							// make easy decision
	void programByILP(TupleRel *, int);				// ILP by CPLEX
	void WGbinaryTest();							// Obtain information of S-O, S-R, and O-R redundancy
	TupleRel * WGgetRemainPredictionFaster(const int, const double, int &, const vector<GrndTrthTriad> &); // construct variables for ILP
	
	// Operation of max-heap
	void hccPop();
	void hccInsert(const int, const int, const double);
	void hccErase(const int);
	void hccMTDown(const int);
	void hccMTUp(const int);

	// For CPLEX
	IloEnv env;				
	IloModel model;			
	IloBoolVarArray d;		
	IloNumArray g;			
	IloCplex cplex;	
};





#endif