#ifndef _BASICDS_H
#define _BASICDS_H

#include <string>
#include <set>
#include <map>
#include <vector>
#include <hash_map>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <math.h>
#include <ilcplex/ilocplex.h>

using namespace std;

// structs
struct StrPair
{
	string str1, str2;
	StrPair(const string & i_str1, const string & i_str2) : str1(i_str1), str2(i_str2){	}

	const bool operator < (const StrPair & other) const {
		if (str1 < other.str1 || str1 == other.str1 && str2 < other.str2) return true;
		return false;
	}
};

struct StrTriple {
	string str1, str2, str3;
	StrTriple(const string & s1, const string & s2, const string & s3) : str1(s1), str2(s2), str3(s3) {	}

	const bool operator < (const StrTriple & other) const {
		if (str1 < other.str1 || str1 == other.str1 && str2 < other.str2 || 
			str1 == other.str1 && str2 == other.str2 && str3 < other.str3) return true;
		return false;
	}
};

struct IntPair{
	int s, t;
	IntPair() {}
	IntPair(const int i_s, const int i_t) : s(i_s), t(i_t) {}
	void setValue(const int i_s, const int i_t) {
		s = i_s; t = i_t;
	}
	const bool operator < (const IntPair & other) const {
		if (s < other.s || s == other.s && t < other.t) return true;
		return false;
	}
	const bool equal_to(const IntPair & other) const {
		if (s == other.s && t == other.t) return true;
		return false;
	}
	const int hash() const {
		return (s + t) * (s + t + 1) / 2 + t;
	}
};

// IDSD: Int-Double pair Sorted by Double
struct IDSD {
	int i; double d;
	IDSD() : i(-1), d(0) {}
	IDSD(const int ii, const double dd) : i(ii), d(dd) {}
	void setValue(const int ii, const double dd) {
		i = ii; d = dd;
	}
	const bool operator < (const IDSD & other) const {
		return d < other.d;
	}
	const bool operator > (const IDSD & other) const {
		return d > other.d;
	}
};
// IDSI: Int-Double pair Sorted by Int
struct IDSI {
	int i; double d;
	IDSI() : i(-1), d(0) {}
	IDSI(const int ii, const double dd) : i(ii), d(dd) {}
	void setValue(const int ii, const double dd) {
		i = ii; d = dd;
	}
	const bool operator < (const IDSD & other) const {
		return i < other.i;
	}
	const bool operator > (const IDSD & other) const {
		return i > other.i;
	}
};

// IIDSII: Int-Int-Double Sorted by Int-Int
struct IIDSIID
{
	int i1, i2; double d;
	IIDSIID() {}
	IIDSIID(const int i_i1, const int i_i2, const double i_d) : i1(i_i1), i2(i_i2), d(i_d) {}
	void setValue(const int i_i1, const int i_i2, const double i_d) {
		i1 = i_i1; i2 = i_i2; d = i_d;
	}
	void setValue(const IIDSIID & o) {
		i1 = o.i1; i2 = o.i2; d = o.d;
	}
	const bool operator < (const IIDSIID & o) const {
		if (i1 < o.i1 || i1 == o.i1 && i2 < o.i2 || i1 == o.i1 && i2 == o.i2 && d < o.d) return true;
		return false;
	}
	const bool operator > (const IIDSIID & o) const {
		if (i1 > o.i1 || i1 == o.i1 && i2 > o.i2 || i1 == o.i1 && i2 == o.i2 && d > o.d) return true;
		return false;
	}
	const bool equalII(const IIDSIID & o) const {
		if (i1 == o.i1 && i2 == o.i2) return true;
		return false;
	}
};

// IIDSII: Int-Int-Double Sorted by Double
struct IIDSD
{
	int i1, i2; double d;
	IIDSD() {}
	IIDSD(const int i_i1, const int i_i2, const double i_d) : i1(i_i1), i2(i_i2), d(i_d){}
	void setValue(const int i_i1, const int i_i2, const double i_d) {
		i1 = i_i1; i2 = i_i2; d = i_d;
	}
	void setValue(const IIDSD & o) {
		i1 = o.i1; i2 = o.i2; d = o.d;
	}
	const bool operator < (const IIDSD & o) const {
		return d < o.d;
	}
	const bool operator >(const IIDSD & o) const {
		return d > o.d;
	}
};


typedef map<string, int> mapsi;
typedef pair<string, int> pairsi;
typedef map<StrPair, int> mapspi;
typedef pair<StrPair, int> pairspi;
typedef map<StrTriple, int> mapsti;
typedef pair<StrTriple, int> pairsti;
typedef map<StrTriple, double> mapstd;
typedef pair<StrTriple, double> pairstd;

// STL Operations

// map<ItemT, int>, and int represents the occurring time
// not found: insert(sp, 1)
// else: int++
template <typename MapT, typename KeyT>
inline const void map2OccurInsert(MapT & m, const KeyT & key) {
	MapT::iterator it = m.find(key);
	if (it == m.end())
		m.insert(pair<KeyT, int>(key, 1));
	else it->second++;
}

// map<ItemT, NumT>
// not found: insert(sp, d)
// else: num += d
template <typename MapT, typename KeyT, typename NumT>
inline const void map2NumInsert(MapT & m, const KeyT & key, const NumT d) {
	MapT::iterator it = m.find(key);
	if (it == m.end())
		m.insert(pair<KeyT, NumT>(key, d));
	else it->second += d;
}

// map<ItemT, NumT>
// not found: insert(sp, d)
// else: num = max(num, d)
template <typename MapT, typename KeyT, typename NumT>
inline const void map2MaxNumInsert(MapT & m, const KeyT & key, const NumT d) {
	MapT::iterator it = m.find(key);
	if (it == m.end())
		m.insert(pair<KeyT, NumT>(key, d));
	else it->second = (it->second > d) ? it->second : d;
}

// map<ItemI, int(id)>
// return the id of given key, insert the key if necessary
template <typename MapT, typename KeyT>
inline const int map2idFind(MapT & m, const KeyT & key) {
	MapT::iterator it = m.find(key);
	if (it != m.end()) return it->second;
	int id = m.size();
	m.insert(pair<KeyT, int>(key, id));
	return id;
}


template <typename MapT>
const void mapPrint(const MapT & m, ofstream & ofs) {
	for (MapT::const_iterator cit = m.begin(); cit != m.end(); ++cit) {
		ofs << cit->first << "\t" << cit->second << endl;
	}
}



// string & char operations
inline const bool isDigit(const char ch) {
	if (ch >= '0' && ch <= '9' || ch == '.') return true;
	return false;
}

struct TupleRel
{
	int subj, obj, rel;
	double conf, mme;	
};

struct GrndTrthTriad {
	int subj, obj, rel;
	GrndTrthTriad(const int & s, const int & o, const int & r) : subj(s), obj(o), rel(r) {}
	GrndTrthTriad() : subj(-1), obj(-1), rel(-1) {}
	const bool operator < (const GrndTrthTriad & o) const {
		if (subj < o.subj || subj == o.subj && obj < o.obj || 
			subj == o.subj && obj == o.obj && rel < o.rel)
			return true;
		else return false;
	}
};

struct SingleMention {
	int epid, domRelPos;	
	vector<int> realRel;
	long double ent, scale;		
	double * pcrs;		// predicted candidate relation score (sorted)
	int * rid;			// relation id (correspond to pcrs)
	int * pos;			// position of relation in rid
	/*
	 * E.g.: 
	 * pcrs[0] = 0.8, pcrs[1] = 0.1, ...
	 * rid[0] = 5,	  rid[1] = 7, ...
	 * pos[5] = 0,	  pos[7] = 1, ...
	 */
};


class Constraint
{
public:
	Constraint();
	~Constraint();
	void setPara(const int, const int);
	void load(const mapsi &);
	bool * getConstraint(const int) const;
	void ConstraintsForILP(const TupleRel *, const int, const IloEnv &, IloModel &, const IloBoolVarArray &);
private:
	// constraint:
	// csr: relationship pair that can not share same subjects;
	// cro: relationship pair that can not share same objects;
	// crer: relationship pair of which the subject of the first can be the object of the second;
	// cou: relationship requiring object unique, i.e. given subject, only one object can be valid;
	// csu: relationship requireing subject unique, i.e. given object, only one subject can be valid;
	bool *csr, *cro, *crer;
	bool *cou, *csu;
	int nV, relC, entityC;

	void typeConstraints(const IntPair *, const IntPair *, const bool *, const TupleRel *, IloModel &, const IloBoolVarArray &);
	void uniqueConstraints(const bool *, const bool, const TupleRel *, const IloEnv &, IloModel &, const IloBoolVarArray &);
};


class Mention
{
public:
	Mention();
	~Mention();
	const SingleMention & operator [](const int);
	void load(const string &, const int, const int);
	
	int getIdxNA() const;
	void loadGroundTruth(set<GrndTrthTriad> &) const;
	void copyCons(const Constraint &);
	void modifyByCons(const int, const int, const map<IntPair, int> &);
	const hash_map<int, double> & getHccUpdate() const;
	const hash_map<int, double> & getHccAdd() const;
	SingleMention * m, * mBackup;	// mBackup is the const copy for m to protect the modifing version; mBackup only record rid, pcrs, pos, epid and realRel
	map<IntPair, int> ep2id;		// entity pair to id

	const IntPair * getId2ep() const;
	const string * getId2entity() const;
	const string * getId2rel() const;
	const int getEpidByEp(const string &, const string) const;
	const int getRidByRel(const string &) const;
	const mapsi & getRel2id() const;
	const map<IntPair, int> & getEp2id() const;	// entity pair to id
	const int getEntityC() const;
	const bool * getcsr() const;
	const bool * getcro() const;
	const bool * getcrer() const;
	const bool * getcou() const;
	const bool * getcsu() const;
	void makeMentOfEntity();		
	void computeEntropy();
	TupleRel * getRemainPrediction(const int, const double, int &, const vector<GrndTrthTriad> &) const;
	void WGmakeMentOfEntityPair();						// build the mention index based on entity pair
	void WGremoveDecisionMade(const int, const int);	// remove all the scores of the decision made in the mentions
	
private:
	int mentC, relC;	
	int idxNA;
	
	mapsi entity2id, rel2id;
	string *id2entity, *id2rel;
	
	IntPair * id2ep;
	int *mentOfSubj, *subjInd, *mentOfObj, *objInd;	// mentions of subjects, mentions of objects
	int *WGmentOfEp, *WGepInd;						// mentions of entitypair

	// constraints
	bool *csr, *cro, *crer;
	bool *cou, *csu;

	hash_map<int, double> hccUpdate;				// the node needing update to the max heap
	hash_map<int, double> hccAdd;					// the node needing add to the max heap

	void makeId2name();

	void eliminate(const int, const int, const map<IntPair, int> &);
	void eliminateStatic(const int, const int, const map<IntPair, int> &);
};


class IO
{
public:
	IO();
	~IO();
	void loadTupleRelConf(const string &, int &, TupleRel * &, mapsi &, mapsi &) const;
	void loadTypeConstraints(const string &, const mapsi &, bool *, const bool) const;
	void loadTypeUniqueness(const string &, const mapsi &, bool *) const;
	void loadGrndTrth(const string &, mapsi &, mapsi &, set<GrndTrthTriad> &) const;
	void loadMentions(const string &, mapsi &, mapsi &, map<IntPair, int> &, SingleMention *, const int) const;
private:
	string nextSubStr(int &, const char, const string &) const;
	void getTriad(const string &, string &, set<string> &, string &) const;
	void getTopRel(const string &, string[], double[], const int) const;
};

class PRCurve
{
public:
	PRCurve();
	~PRCurve();
	static void draw(const TupleRel *, const int, const set<GrndTrthTriad> &, const vector<GrndTrthTriad> &,
		const IloCplex &, const IloBoolVarArray &, const Mention &, const vector<double> &);

private:
	
};

extern string subjNotShare;
extern string objNotShare;
extern string subjObjNotShare;
extern string subjUnique;
extern string objUnique;

extern string dir;
extern int mentC;
extern int relC;
extern int eC;
extern double ThreType;
extern double ThreUniqueness;
extern double ThreConfBase;

#endif