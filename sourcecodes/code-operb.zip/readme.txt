The package is a java implement of the paper:
*************************************************
One-Pass Error Bounded Trajectory Simplification. 
The 43rd International Conference on Very Large Data Bases (VLDB), Munich, Germany, 2017.
Xuelian Lin, Shuai Ma*, Han Zhang, Tianyu Wo, and Jinpeng Huai.
{linxl, mashuai, zhanghan, woty, huaijp}@buaa.edu.cn
*************************************************
You can find the paper and dataset at website "http://mashuai.buaa.edu.cn/traj.html"


1. Main classes in the package
Class org.act.traj.OPERB implements the one pass error bounded trajectory simplification algorithm. 
Class org.act.traj.TestOPERB is a test case which provides more info about OPERB.


2. How to use OPERB: 
---------------------------------------------------------------------------
	//step 1. new OPERB
	BasicOPERP tc = new OPERB();
			
	//step 2. set the error bound
	tc.threshold = 20;							
	   		
	//step 3. set the input data file and load the data into memory. 
	//Note, one can modify this to an input stream.
	tc.strFileName = ".\\data\\GeoLife\\002" + ".txt";//set the input data file name
	tc.loadTrajectory();
	 	   	
	//step 4. compress.
	//Also, the output data structure could be modified to an output stream.
	GPSLine[] lines =  tc.compress();         	
---------------------------------------------------------------------------
