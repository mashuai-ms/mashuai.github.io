#!/usr/bin/python
# ==================================================================================
#
#       Filename:  alg_sim.py
#
#    Description:  
#
#        Version:  1.0
#        Created:  04/17/2011 08:32:37 PM
#       Revision:  none
#       Language:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================

import graph_tool.all as gt
_DEBUG = False

Qgraph = gt.load_graph("Qgraph.xml.gz")
Dgraph = gt.load_graph("Dgraph.xml.gz")

def sim_initialization(sim, remove):
    '''
    Initialize main data structures for simulation algorithm
    '''
    global Qgraph
    global Dgraph
    pre_dgraph_vertices = set(v for v in Dgraph.vertices() if v.out_degree() != 0)
    for u in Qgraph.vertices():
#        prevsim[u] = set(Dgraph.vertices())
        if u.out_degree() == 0:
            sim[u] = set(v for v in Dgraph.vertices() if Qgraph.vertex_properties["label"][u] == Dgraph.vertex_properties["label"][v])
        else:
            sim[u] = set(v for v in Dgraph.vertices() if Qgraph.vertex_properties["label"][u] == Dgraph.vertex_properties["label"][v] and v.out_degree() != 0)
        remove[u] = pre_dgraph_vertices.difference(set(v for w in sim[u] for v in w.in_neighbours()))



def counter_initialization(sim_counter, sim):
    '''
    Initialize the 2-dimensional list sim_counter such that sim_counter[v][u] denotes the cardinality of post(v) \cap sim(u).
    '''
    global Qgraph
    global Dgraph
    for w in Dgraph.vertices():
        for u in Qgraph.vertices():
            sim_counter[int(w)][int(u)] = len(set(w.out_neighbours()).intersection(sim[u]))
 

def find_nonempty_remove(remove):
    '''
    Return (the first) u if remove[u] is not empty. Otherwise return None.
    '''
    global Qgraph
    for u in Qgraph.vertices():
        if len(remove[u]) !=  0:
            return u

    return None


def update_sim_counter(sim_counter, u_p, w):
    '''
    '''
    for wp in w.in_neighbours():
        if sim_counter[int(wp)][int(u_p)] > 0:
            sim_counter[int(wp)][int(u_p)] = sim_counter[int(wp)][int(u_p)] - 1


def assert_check(setA, setB):
    '''
    Return True if vertices in setA have the same indices to those in setB
    '''
    for v in setA:
        flag = 1
        for u in setB:
            if int(v) == int(u):
                flag = 0
                break
        if flag == 1:
            return False
    return True


def sim_refinement(sim, remove):
    '''
    Decrementally refine sim untile all remove sets are all empty.
    '''
    global Qgraph
    global Dgraph
    #a counter used to speedup the refinement
    sim_counter = [[0 for col in xrange(0,Qgraph.num_vertices())] for row in xrange(0, Dgraph.num_vertices())] 
    #note that if the memory of your machine is relative small, you can (c)pickle it to harddisk in order to save memory

    counter_initialization(sim_counter, sim)
    u = find_nonempty_remove(remove)
    while u != None:
        #a set of assertions
#        for ass_u in Qgraph.vertices():
#            assert assert_check(remove[ass_u], set(v for w in prevsim[ass_u] for v in w.in_neighbours()).difference(set(v for w in sim[ass_u] for v in w.in_neighbours()))) is True
        for u_p in u.in_neighbours():
            for w in remove[u]:
                if w in sim[u_p]:
                    sim[u_p].discard(w)
                    update_sim_counter(sim_counter, u_p, w)
                    for w_p in w.in_neighbours():
                        if sim_counter[int(w_p)][int(u_p)] == 0:
                            remove[u_p].add(w_p)
        if _DEBUG == True:
            import pdb
            pdb.set_trace()
#        prevsim[u]=sim[u]
#        prevsim[u] = set(v for v in sim[u])
        remove[u].clear()
        u = find_nonempty_remove(remove)


def match_check(sim):
    '''
    Check whether sim is a matching relation for dual simulation.
    '''
    global Qgraph
    for u in Qgraph.vertices():
        if len(sim[u]) == 0:
            return False
    return True

def sim_output(sim):
    '''
    Output the matching relation if exists
    '''
    global Qgraph
    if match_check(sim) == True:
        for u in Qgraph.vertices():
            print 'sim[%d] is %s' % (int(u), sim[u])
    else:
        print 'Dgraph cannot match Qgraph via graph simulation!'
        return None

    return sim


def graph_simulation():
    '''
    Graph simulation algorithm returns the set of simulation relations of Ggraph for Qgraph
    '''
#    prevsim = {}
    sim = {}
    remove = {}

    sim_initialization(sim, remove)
    sim_refinement(sim, remove)
    return sim_output(sim)



if __name__ == "__main__":
    graph_simulation()
