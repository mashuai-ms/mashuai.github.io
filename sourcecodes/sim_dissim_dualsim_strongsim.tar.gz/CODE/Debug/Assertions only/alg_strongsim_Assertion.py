#!/usr/bin/python
# ==================================================================================
#
#       Filename:  alg_strongsim_Assertion.py
#
#    Description:  Strong simulation based on dual simulation.
#
#        Version:  1.0
#        Created:  04/18/2011 14:59:36
#       Revision:  none
#       Compiler:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================


import modular_dual_simulation_Assert as ds
import graph_tool.all as gt

Qgraph = gt.load_graph("Qgraph.xml.gz")
Dgraph = gt.load_graph("Dgraph.xml.gz")

def cal_diameter_qgraph(qgraph):
    '''
    Calculate the diameter of qgraph
    '''
    temp_dia = 0
    max_dia = qgraph.num_vertices()-1
    for u in qgraph.vertices():
        dist = gt.shortest_distance(qgraph, u, None, None, False)
        for i in xrange(0, len(dist.a)):
            if dist.a[i] <= max_dia and temp_dia < dist.a[i]:
                temp_dia = dist.a[i]

    return temp_dia


def create_ball_view(w, d_Q):
    '''
    Create a ball [w, d_Q] view on top of data graph
    '''
    global Dgraph
    dist = gt.shortest_distance(Dgraph, w, None, None, False)
    ball_view = gt.GraphView(Dgraph, vfilt = lambda v: dist.a[int(v)] <= d_Q)
    return ball_view
    

def extract_max_pg(ball_view, qgraph, w, S_w, d_Q):
    '''
    Extract the maximum perfect graph of qgraph in the ball.
    '''
    if S_w == None:
        return None

    uid = -1
    for u in qgraph.vertices():
        if w in S_w[u]:
            uid = int(u)
            break
    if uid == -1:
        return None

    vertex_matchset = set(v for u in qgraph.vertices() for v in S_w[u])
    edge_matchset = set(e for e in ball_view.edges() for (u, v) in qgraph.edges() if e.source() in S_w[u] and e.target() in S_w[v])
    pg_view = gt.GraphView(ball_view, vfilt = lambda v: v in vertex_matchset, efilt = lambda e: e in edge_matchset)
    dist = gt.shortest_distance(pg_view, w, None, None, False)
    maxPGC = gt.GraphView(pg_view, vfilt = lambda v: dist.a[int(v)] <= d_Q)
    return maxPGC



def output_max_pgs(max_perfect_subgraphs):
    '''
    Out put maximum perfect subgraphs.
    '''
    if len(max_perfect_subgraphs) == 0:
        print 'There is no perfect subgraph!'
    for maxPG in max_perfect_subgraphs:
        print '>>>>>One PG is %s' % maxPG

    return max_perfect_subgraphs


def is_the_same(g1, g2):
    '''
    Check whether g1 and g2 are the "same".
    '''
    for u in g1.vertices():
        flag = 0
        for v in g2.vertices():
            if int(v) == int(u):
                flag = 1
                break
        if flag == 0:
            return False

    return True



def is_new_pg(G_s, max_perfect_subgraphs):
    '''
    Check whether G_s is a new PG
    '''
    if G_s == None:
        return False
    for g in max_perfect_subgraphs:
        if is_the_same(g, G_s) == True:
            return False
    return True

def strong_simulation():
    '''
    A cubic time strong simulation algorithm based on dual simulation
    '''
    global Dgraph
    global Qgraph

    d_Q = cal_diameter_qgraph(Qgraph)

    max_perfect_subgraphs = set()
    for w in Dgraph.vertices():
        ball_view = create_ball_view(w, d_Q)
        S_w = {}
        ds.dual_simulation(ball_view, Qgraph, S_w, False)
        G_s = extract_max_pg(ball_view, Qgraph, w, S_w, d_Q)
        if is_new_pg(G_s, max_perfect_subgraphs) == True:
            max_perfect_subgraphs.add(G_s)

    output_max_pgs(max_perfect_subgraphs)

if __name__ == "__main__":
    strong_simulation()
