#!/usr/bin/python
# ==================================================================================
#
#       Filename:  alg_strongsim_opt_Assertion.py
#
#    Description:  Strong simulation based on dual simulation.
#
#        Version:  1.0
#        Created:  04/18/2011 14:59:36
#       Revision:  none
#       Compiler:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================


import modular_dual_simulation_Assert as ds
import graph_tool.all as gt

Qgraph = gt.load_graph("Qgraph.xml.gz")
Dgraph = gt.load_graph("Dgraph.xml.gz")

def cal_diameter_qgraph(qgraph):
    '''
    Calculate the diameter of qgraph
    '''
    temp_dia = 0
    max_dia = qgraph.num_vertices()-1
    for u in qgraph.vertices():
        dist = gt.shortest_distance(qgraph, u, None, None, False)
        for i in xrange(0, len(dist.a)):
            if dist.a[i] <= max_dia and temp_dia < dist.a[i]:
                temp_dia = dist.a[i]

    return temp_dia


def create_ball_view(w, d_Q):
    '''
    Create a ball [w, d_Q] view on top of data graph
    '''
    global Dgraph
    dist = gt.shortest_distance(Dgraph, w, None, None, False)
    ball_view = gt.GraphView(Dgraph, vfilt = lambda v: dist.a[int(v)] <= d_Q)
    return ball_view
   



def remove_equiv_nodes(qgraph, S_Q):
    '''
    Remove equivalent nodes from qgraph.
    u is equivalent to v iff v\in S_Q[u] and u\in S_Q[v]
    '''
    mark = [0 for col in xrange(0, qgraph.num_vertices())]
    for u in qgraph.vertices():
        for v in qgraph.vertices():
            if mark[int(u)] == 0 and mark[int(v)] == 0 and int(u) != int(v) and u in S_Q[v] and v in S_Q[u]:
                for v_p in v.in_neighbours():
                    if (v_p, u) not in qgraph.edges():
                        qgraph.add_edge(v_p, u)
                for v_s in v.out_neighbours():
                    if (v_s, u) not in qgraph.edges():
                        qgraph.add_edge(v_s, u)
                mark[int(v)] = 1
    qgraph_view = gt.GraphView(qgraph, vfilt = lambda v: mark[int(v)] == 0)
    gt.remove_parallel_edges(qgraph_view)
    qgraph_view.purge_vertices()



def query_minimization(qgraph):
    '''
    Minimize Qgraph
    '''
    S_Q = {}
    ds.dual_simulation(qgraph, qgraph, S_Q, False)
    remove_equiv_nodes(qgraph, S_Q)





def valid_sim_w(sim, w, qgraph):
    '''
    Check whether the matching relation sim contains w or not
    '''
    if sim == None:
        return False

    uid = -1
    for u in qgraph.vertices():
        if w in sim[u]:
            uid = int(u)
            break
    if uid == -1:
        return False

    return True

  



def extract_max_pg(ball_view, qgraph, w, S_w, d_Q):
    '''
    Extract the maximum perfect graph of qgraph in the ball.
    '''
    if valid_sim_w(S_w, w, qgraph) == False:
        return None

    vertex_matchset = set(v for u in qgraph.vertices() for v in S_w[u])
    edge_matchset = set(e for e in ball_view.edges() for (u, v) in qgraph.edges() if e.source() in S_w[u] and e.target() in S_w[v])
    pg_view = gt.GraphView(ball_view, vfilt = lambda v: v in vertex_matchset, efilt = lambda e: e in edge_matchset)
    dist = gt.shortest_distance(pg_view, w, None, None, False)
    maxPGC = gt.GraphView(pg_view, vfilt = lambda v: dist.a[int(v)] <= d_Q)
    return maxPGC



def output_max_pgs(max_perfect_subgraphs):
    '''
    Out put maximum perfect subgraphs.
    '''
    if len(max_perfect_subgraphs) == 0:
        print 'There is no perfect subgraph!'
    for maxPG in max_perfect_subgraphs:
        print '>>>>>One PG is %s' % maxPG

    return max_perfect_subgraphs


def is_the_same(g1, g2):
    '''
    Check whether g1 and g2 are the "same".
    '''
    for u in g1.vertices():
        flag = 0
        for v in g2.vertices():
            if int(v) == int(u):
                flag = 1
                break
        if flag == 0:
            return False

    return True



def is_new_pg(G_s, max_perfect_subgraphs):
    '''
    Check whether G_s is a new PG
    '''
    if G_s == None:
        return False
    for g in max_perfect_subgraphs:
        if is_the_same(g, G_s) == True:
            return False
    return True


def project_sim(ball, sim):
    '''
    Project global matching relation sim to ball and return the projected relation.
    '''
    global Qgraph
    ball_sim = {}
    for u in Qgraph.vertices():
        ball_sim[u] = set(v for v in ball.vertices() if v in sim[u])
    return ball_sim



def connectivity_prune(ball, w, sim, d_Q):
    '''
    Use the matching relation sim to prune the ball
    '''
    global Qgraph
    tmp = set(v for u in Qgraph.vertices() for v in sim[u] if v in ball.vertices())
    view_1 = gt.GraphView(ball, vfilt = lambda v: v in tmp)
    dist = gt.shortest_distance(view_1, w, None, None, False)
    view_2 = gt.GraphView(view_1, vfilt = lambda v: dist.a[int(v)] <= d_Q)
    return view_2


def remap_counter_id(ftf, ball):
    '''
    Remap vertex id
    '''
    fid = 0
    for v in ball.vertices():
        ftf[int(v)] = fid
        fid += 1
        assert fid <= ball.num_vertices()

def ss_counter_initialization(counter_ps, counter_ss, ball, qgraph, sim, ftf):
    '''
    Counter initialization
    '''
    for v in ball.vertices():
        for u in qgraph.vertices():
            counter_ps[ftf[int(v)]][int(u)] = len(set(vp for vp in v.in_neighbours() if vp in sim[u]))
            counter_ss[ftf[int(v)]][int(u)] = len(set(vs for vs in v.out_neighbours() if vs in sim[u]))


def is_border_node(v, ball, w, d_Q):
    '''
    Judge whether v is a border node of ball[w]
    '''
    dist = gt.shortest_distance(ball, w, None, None, False)
    if dist.a[int(v)] == d_Q:
        return True
    return False



def push_phase(counter_ps, counter_ss, ball, qgraph, sim, filter_set, w, ftf, d_Q):
    '''
    Push all possible fake matches that involve the border nodes
    '''
    for u in qgraph.vertices():
        for v in sim[u]:
            if is_border_node(v, ball, w, d_Q) == True:
                for u_s in u.out_neighbours():
                    if counter_ss[ftf[int(v)]][int(u_s)] == 0:
                        filter_set.add((u,v))
                        break
                for u_p in u.in_neighbours():
                    if counter_ps[ftf[int(v)]][int(u_p)] == 0:
                        filter_set.add((u,v))
                        break


def update_counter(counter_ps, counter_ss, ball, u, v, ftf):
    '''
    Update counters
    '''
    for vp in v.in_neighbours():
        assert vp in ball.vertices()
        if counter_ss[ftf[int(vp)]][int(u)] > 0:
            counter_ss[ftf[int(vp)]][int(u)] -= 1

    for vs in v.out_neighbours():
        assert vs in ball.vertices()
        if counter_ps[ftf[int(vs)]][int(u)] > 0:
            counter_ps[ftf[int(vs)]][int(u)] -= 1


def decremental_refine(counter_ps, counter_ss, ball, qgraph, S_w, filter_set, ftf):
    '''
    Decrementally refine S_w
    '''
    while len(filter_set) != 0:
        (u, v) = filter_set.pop()
        S_w[u].remove(v)
        update_counter(counter_ps, counter_ss, ball, u, v, ftf)
        for u_p in u.in_neighbours():
            for v_p in v.in_neighbours():
                assert v_p in ball.vertices()
                if v_p in S_w[u_p]:
                    if counter_ss[ftf[int(v_p)]][int(u)] == 0:
                        filter_set.add((u_p, v_p))
        for u_s in u.out_neighbours():
            for v_s in v.out_neighbours():
                assert v_s in ball.vertices()
                if v_s in S_w[u_s]:
                    if counter_ps[ftf[int(v_s)]][int(u)] == 0:
                        filter_set.add((u_s, v_s))




def dual_filter_match(refined_ball, qgraph, S_w, w, d_Q):
    '''
    dualFilter: refine the initial S_w to get the final matching relation
    '''
    filter_set = set()
    counter_ps = [[0 for col in xrange(0, qgraph.num_vertices())] for row in xrange(0, refined_ball.num_vertices())]
    counter_ss = [[0 for col in xrange(0, qgraph.num_vertices())] for row in xrange(0, refined_ball.num_vertices())]
    ftf = {}
    remap_counter_id(ftf, refined_ball)
    ss_counter_initialization(counter_ps, counter_ss, refined_ball, qgraph, S_w, ftf)
    
    push_phase(counter_ps, counter_ss, refined_ball, qgraph, S_w, filter_set, w, ftf, d_Q)

    decremental_refine(counter_ps, counter_ss, refined_ball, qgraph, S_w, filter_set, ftf)
    for u in qgraph.vertices():
        if len(S_w[u]) == 0:
            S_w = {}
            return S_w

    return S_w


def rename_sim(S_w, ball):
    '''
    Reconstruct S_w using vertices in ball
    '''
    global Qgraph
    tmp = {}
    for u in Qgraph.vertices():
        tmp[u] = set()
        for v in ball.vertices():
            if v in S_w[u]:
                tmp[u].add(v)
    return tmp


def strong_simulation_opt():
    '''
    Enhanced strong simulation algorithm
    '''
    global Dgraph
    global Qgraph

    d_Q = cal_diameter_qgraph(Qgraph)
    max_perfect_subgraphs = set()
    query_minimization(Qgraph)

    global_sim = {}
    ds.dual_simulation(Dgraph, Qgraph, global_sim, False)

    for w in Dgraph.vertices():
        if valid_sim_w(global_sim, w, Qgraph) == True:
            ball_view = create_ball_view(w, d_Q)
            S_w = project_sim(ball_view, global_sim)
            refined_ball_view = connectivity_prune(ball_view, w, S_w, d_Q)
            S_w = rename_sim(S_w, refined_ball_view)
#            ds.dual_simulation(refined_ball_view, Qgraph, S_w, True)
            dual_filter_match(refined_ball_view, Qgraph, S_w, w, d_Q)
            G_s = extract_max_pg(refined_ball_view, Qgraph, w, S_w, d_Q)
            if is_new_pg(G_s, max_perfect_subgraphs) == True:
                max_perfect_subgraphs.add(G_s)

    output_max_pgs(max_perfect_subgraphs)

if __name__ == "__main__":
    strong_simulation_opt()
