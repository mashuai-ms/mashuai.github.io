#!/usr/bin/python
# ==================================================================================
#
#       Filename:  creat_graph.py
#
#    Description:  Create query and data graphs from specified data files.
#
#        Version:  1.0
#        Created:  04/17/2011 09:52:42 AM
#       Revision:  none
#       Compiler:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================



import glob
import os
import graph_tool.all as gt
from itertools import izip
from numpy.random import randint
import numpy as np # used for matrix operation in a high speed
#import fpconst #inf, -inf, nom
import sys #print sys.maxint
import random


Dgraph = gt.Graph();
Qgraph = gt.Graph();


def generate_synthetic_graphs(n=1000, a=1.20, l=200):
    '''
    @Attention: generated graph has "int" vertex_properties, different from graphs create by create_graph.py which has "string" vertex_properties. 
    Generate synthetic graphs
    @param n: number of vertices
    @param a: n^a is the number of edges (usually we use a in [1.05, 1.35])
    @param l: number of different labels [0,l)
    '''
    g = gt.Graph()
    g.add_vertex(n)
    for c in xrange(0, int(n**a)):
        a = random.randint(0, n-1)
        b = random.randint(0, n-1)
        g.add_edge(g.vertex(a), g.vertex(b))

    g.vertex_properties["label"] = g.new_vertex_property("int")
    for v in g.vertices():
        g.vertex_properties["label"][v] = random.randint(0,l)

    return g


def generate_Qgraph():
    '''
    Generate query graph
    '''
    global Qgraph
    Qgraph = generate_synthetic_graphs(5)
    print 'synthetic_qgraph: %s' %Qgraph


def generate_Dgraph():
    '''
    Generate data graph
    '''
    global Dgraph
    Dgraph = generate_synthetic_graphs(100)
    print 'synthetic_dgraph: %s' %Dgraph


if __name__ == "__main__":
    curdir = os.getcwd()
    os.chdir(curdir)
    remfilelist = glob.glob('*.gz')

    print 'Delete the following files?'
    print remfilelist
    usercommand = raw_input('Input Y or N:')
    while usercommand <> 'Y' and usercommand <> 'N':
        usercommand = raw_input('Input Y or N:')
    if usercommand == 'Y':
        for name in remfilelist:
            os.remove(name)
               
    generate_Qgraph()
    print 'The query graph is %s' %Qgraph
    print 'The list_properties of Qgraph are %s' %Qgraph.list_properties()
    Qgraph.save("Qgraph.xml.gz")

    generate_Dgraph()
    print 'The data graph is %s' %Dgraph
    print 'The list_properties of Dgraph are %s' %Dgraph.list_properties()
    Dgraph.save("Dgraph.xml.gz")
    gt.graph_draw(Qgraph, vprops = {"label": Qgraph.vertex_properties["label"]}, output = "QueryGraph.png")
    gt.graph_draw(Dgraph, vprops = {"label": Dgraph.vertex_properties["label"]}, output = "DataGraph.png")
