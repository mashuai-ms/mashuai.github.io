#!/usr/bin/python
# ==================================================================================
#
#       Filename:  alg_appro.py
#
#    Description:  Approximation algorithm for approximate matching via MSC
#
#        Version:  1.0
#        Created:  04/19/2011 10:32:37
#       Revision:  none
#       Compiler:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================


import graph_tool.all as gt
Qgraph = gt.load_graph("Qgraph.xml.gz")
Dgraph = gt.load_graph("Dgraph.xml.gz")



def max_set(S_1, S_2):
    '''
    Return the larger vertices set
    '''
    if S_1 != None and S_2 != None:
        if len(S_1) > len(S_2):
            return S_1
        return S_2
    elif S_1 == None:
        return S_2
    else:
        return S_1


def ramsey(V_G):
    '''
    Ramsey algorithm
    Return (C,I)
    '''
    global Dgraph
    print 'start ramsey...'
    if len(V_G) == 0:
        print 'return (0, 0)'
        return (V_G, V_G)
    for u in V_G:
        N_u = set(v for v in V_G if v in u.all_neighbours() and v != u)
        M_u = set(v for v in V_G if v not in u.all_neighbours() and v != u)
        print 'N_u = %s' % N_u
        print 'M_u = %s' % M_u
        (C_1, I_1) = ramsey(N_u)
        (C_2, I_2) = ramsey(M_u)
        C_1.add(u)
        I_2.add(u)
        print 'return max_set(%s, %s)= %s' %(C_1, C_2, max_set(C_1,C_2))
        return (max_set(C_1, C_2), max_set(I_1, I_2.add(u)))

def ISRemoval(graph):
    '''
    Ramsey based maximum clique approximation algorithm.
    Output: A clique C of graph
    '''
    V = set(graph.vertices())
    i = 1
    C={}
    I={}
    (C[i], I[i]) = ramsey(V)
    while len(V) != 0:
        V.difference_update(I[i])
        i = i + 1
        print 'i = %d' %i
        (C[i], I[i]) = ramsey(V)
    
    id = 1
    ll = len(C[1])
    for j in xrange(1, i+1):
        if len(C[j]) > ll:
            id = j
            ll = len(C[id])

    return C[id]


def deriving_graph(g1, g2):
    '''
    Given two graphs, construct a derived graph (compatible product graph) for maximum common subgraph
    '''
    derived_graph = gt.Graph()
    derived_graph.add_vertex(g1.num_vertices() * g2.num_vertices())
    derived_graph.vertex_properties["label"] = derived_graph.new_vertex_property("vector<int>")
    id = 0
    for u in g1.vertices():
        for v in g2.vertices():
            derived_graph.vertex_properties["label"][derived_graph.vertex(id)] = [int(u), int(v)]
            id += 1

    for u1 in g1.vertices():
        for u2 in g2.vertices():
            for v1 in g1.vertices():
                for v2 in g2.vertices():
                    if (u1,v1) in g1.edges() and (u2,v2) in g2.edges():
                        w1_id = 0
                        for v in derived_graph.vertices():
                            if derived_graph.vertex_properties["label"][v] == [int(u1), int(u2)]:
                                w1_id = int(v)
                                break
                        w2_id = 0
                        for vv in derived_graph.vertices():
                            if derived_graph.vertex_properties["label"][vv] == [int(v1), int(v2)]:
                                w2_id = int(vv)
                                break
                        derived_graph.add_edge(derived_graph.vertex(w1_id), derived_graph.vertex(w2_id))
    print 'when g1 = %s, g2 = %s \n, derived_graph(g1, g2) = %s' % (g1, g2, derived_graph)
    return derived_graph

def match_via_mcs(g1, g2):
    '''
    Judge g1 matches g2 via msc, if YES, return the MCS
    '''
    dg = deriving_graph(g1, g2)
    clique = ISRemoval(dg)
    ab = len(clique)
    be = g1.num_vertices()
    if be < g2.num_vertices():
        be = g2.num_vertices()
    if ab/be >= 0.7:
        print 'g1=%s matches g2=%s' %(g1, g2)
        la = set()
        for v in clique:
            [a_id, b_id] = dg.vertex_properties["label"][v] 
            la.add(g2.vertex(b_id))
        g2_view = gt.GraphView(g2, vflit = lambda v: v in la)
        return g2_view
    return None


if __name__ == "__main__":
    '''
    Approximation matching based on MCS
    '''
    global Qgraph
    global Dgraph
    motifs, counts = gt.motifs(Dgraph, Qgraph.num_vertices())
    print 'motifs = %s, len(motifs) = %d, counts=%s' %(motifs, len(motifs), counts)
    
    match_set = set()
    for mid in xrange(0,len(motifs)):
        vm, em = gt.subgraph_isomorphism(motifs[mid], Dgraph)
        print 'len(vm) = %d' %len(vm)
        for i in xrange(0, len(vm)):
            Dgraph.set_vertex_filter(None)
            Dgraph.set_edge_filter(None)
            vmask, emask = gt.mark_subgraph(Dgraph, motifs[mid], vm[i], em[i])
            g2 = gt.GraphView(Dgraph, vfilt = vmask, efilt = emask)
            match_set.add(match_via_mcs(Qgraph,g2)) 

    print 'match_set = %s' %match_set
