#!/usr/bin/python
# ==================================================================================
#
#       Filename:  alg_sim.py
#
#    Description:  
#
#        Version:  1.0
#        Created:  04/17/2011 08:32:37 PM
#       Revision:  none
#       Language:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================

import graph_tool.all as gt
_DEBUG = False

Qgraph = gt.load_graph("Qgraph.xml.gz")
Dgraph = gt.load_graph("Dgraph.xml.gz")

def sim_initialization(prevsim, sim, remove):
    '''
    Initialize main data structures for simulation algorithm
    '''
    global Qgraph
    global Dgraph
    pre_dgraph_vertices = set(v for v in Dgraph.vertices() if v.out_degree() != 0)
    print 'Initially, pre(V) = %s' % pre_dgraph_vertices
    for u in Qgraph.vertices():
        prevsim[u] = set(Dgraph.vertices())
        if u.out_degree() == 0:
            sim[u] = set(v for v in Dgraph.vertices() if Qgraph.vertex_properties["label"][u] == Dgraph.vertex_properties["label"][v])
            print 'sim[%d] = %s' % (int(u), sim[u])
        else:
            sim[u] = set(v for v in Dgraph.vertices() if Qgraph.vertex_properties["label"][u] == Dgraph.vertex_properties["label"][v] and v.out_degree() != 0)
            print 'sim[%d] = %s' % (int(u), sim[u])
        remove[u] = pre_dgraph_vertices.difference(set(v for w in sim[u] for v in w.in_neighbours()))
        print 'remove[%d] = %s' % (int(u), remove[u])

    print '==============='
    print 'Initialization Complete.'
    print '==============='


def counter_initialization(sim_counter, sim):
    '''
    Initialize the 2-dimensional list sim_counter such that sim_counter[v][u] denotes the cardinality of post(v) \cap sim(u).
    '''
    global Qgraph
    global Dgraph
    for w in Dgraph.vertices():
        for u in Qgraph.vertices():
            sim_counter[int(w)][int(u)] = len(set(w.out_neighbours()).intersection(sim[u]))
 

def find_nonempty_remove(remove):
    '''
    Return (the first) u if remove[u] is not empty. Otherwise return None.
    '''
    global Qgraph
    for u in Qgraph.vertices():
        if len(remove[u]) !=  0:
            print '\n ****  ****  **** \n remove[%d] is NOT empty! IT IS %s' %(int(u), remove[u])
            return u

    print 'TERMINATION: all remove sets are empty NOW!'
    return None


def update_sim_counter(sim_counter, u_p, w):
    '''
    '''
    for wp in w.in_neighbours():
        if sim_counter[int(wp)][int(u_p)] > 0:
            sim_counter[int(wp)][int(u_p)] = sim_counter[int(wp)][int(u_p)] - 1
            print 'Update counter: sim_counter[%d][%d] --' % (int(wp), int(u_p))


def assert_check(setA, setB):
    '''
    Return True if vertices in setA have the same indices to those in setB
    '''
    for v in setA:
        flag = 1
        for u in setB:
            if int(v) == int(u):
                flag = 0
                break
        if flag == 1:
            return False
    return True


def sim_refinement(prevsim, sim, remove):
    '''
    Decrementally refine sim untile all remove sets are all empty.
    '''
    global Qgraph
    global Dgraph
    #a counter used to speedup the refinement
    sim_counter = [[0 for col in xrange(0,Qgraph.num_vertices())] for row in xrange(0, Dgraph.num_vertices())] 
    #note that if the memory of your machine is relative small, you can (c)pickle it to harddisk in order to save memory

    counter_initialization(sim_counter, sim)
    print 'The initialized counter is %s' % sim_counter
    u = find_nonempty_remove(remove)
    while u != None:
        #a set of assertions
        print 'Begin asserting...'
        for ass_u in Qgraph.vertices():
            print 'remove[%d] is %s' % (int(ass_u), remove[ass_u])
            print 'prevsim[%d] is %s' % (int(ass_u), prevsim[ass_u])
            print 'pre(prevsim[%d]) is %s' % (int(ass_u), set(v for w in prevsim[ass_u] for v in w.in_neighbours()))
            print 'sim[%d] is %s' % (int(ass_u), sim[ass_u])
            print 'pre(sim[%d]) is %s' % (int(ass_u), set(v for w in sim[ass_u] for v in w.in_neighbours()))
            print 'pre(prevsim[%d]) - pre(sim[%d]) is %s' % (int(ass_u), int(ass_u), set(v for w in prevsim[ass_u] for v in w.in_neighbours()).difference(set(v for w in sim[ass_u] for v in w.in_neighbours())))
            assert assert_check(remove[ass_u], set(v for w in prevsim[ass_u] for v in w.in_neighbours()).difference(set(v for w in sim[ass_u] for v in w.in_neighbours()))) is True
        print '//////// assertion complete this iteration //////////'
        for u_p in u.in_neighbours():
            for w in remove[u]:
                if w in sim[u_p]:
                    sim[u_p].discard(w)
                    print 'Delete %d from sim[%d]' % (int(w), int(u_p))
                    print 'Updating the counter ...'
                    update_sim_counter(sim_counter, u_p, w)
                    print 'Now the counter is %s' % sim_counter
                    for w_p in w.in_neighbours():
                        if sim_counter[int(w_p)][int(u_p)] == 0:
                            remove[u_p].add(w_p)
                            print 'counter[%d][%d]=%d, Add %d to remove[%d]' % (int(w_p), int(u_p), sim_counter[int(w_p)][int(u_p)], int(w_p), int(u_p))
        if _DEBUG == True:
            import pdb
            pdb.set_trace()
#        prevsim[u]=sim[u]
        prevsim[u] = set(v for v in sim[u])
        print 'Update prevsim[%d]=sim[%d]=%s' % (int(u), int(u), prevsim[u])
        remove[u].clear()
        print 'Clear remove[%d]' % int(u)
        u = find_nonempty_remove(remove)


def match_check(sim):
    '''
    Check whether sim is a matching relation for dual simulation.
    '''
    global Qgraph
    for u in Qgraph.vertices():
        if len(sim[u]) == 0:
            return False
    return True

def sim_output(sim):
    '''
    Output the matching relation if exists
    '''
    global Qgraph
    if match_check(sim) == True:
        print 'Dgraph matches Qgraph via graph simulation. The matching relation is:'
        for u in Qgraph.vertices():
            print 'sim[%d] is %s' % (int(u), sim[u])
    else:
        print 'Dgraph cannot match Qgraph via graph simulation!'
        return None

    return sim


def graph_simulation():
    '''
    Graph simulation algorithm returns the set of simulation relations of Ggraph for Qgraph
    '''
    prevsim = {}
    sim = {}
    remove = {}

    sim_initialization(prevsim, sim, remove)
    sim_refinement(prevsim, sim, remove)
    return sim_output(sim)



if __name__ == "__main__":
    graph_simulation()
