#!/usr/bin/python
# ==================================================================================
#
#       Filename:  creat_graph.py
#
#    Description:  Create query and data graphs from specified data files.
#
#        Version:  1.0
#        Created:  04/17/2011 09:52:42 AM
#       Revision:  none
#       Compiler:  python
#
#         Author:  Yang Cao
#       Homepage:  http://www.act.buaa.edu.cn/caoyang
#          Email:  caoyang@act.buaa.edu.cn  OR  yang.cao999@gmail.com
#        Company:  BUAA
#
# ==================================================================================



import glob
import os
import graph_tool.all as gt
from itertools import izip
from numpy.random import randint
import numpy as np # used for matrix operation in a high speed
#import fpconst #inf, -inf, nom
import sys #print sys.maxint

Dgraph = gt.Graph();
Qgraph = gt.Graph();

def get_from_xml(graph, xmlname):
    '''
    derive a graph from a xml file
    @xmlname, a string
    @graph, a graph derived from the xml file 
    '''
    pass


def get_from_adjacent_matrix(graph, adjacent_matrix_file):
    '''
    Derive the graph from an adjacent matrix text file.

    @attention: 1) a number N in the first line must be specified to give the number of nodes in the graph;
                2) N node attributes of strings are givin in the second line;
                3) the connection adjacent matrix are given in the following N lines, each line for a vertex;
                4) all items are separated by space

    @param graph: a graph object 
    '''
    
    try:
        ad_matrix = open(adjacent_matrix_file, 'U')
    except IOError:
        print "Error: file %s not exists" % adjacent_matrix_file

    num_vertices = int(ad_matrix.readline())
    graph.add_vertex(num_vertices)

    labels = ad_matrix.readline().split()
    assert len(labels) is num_vertices
    graph.vertex_properties["label"] = graph.new_vertex_property("string")
    for i in xrange(0, len(labels)):
        graph.vertex_properties["label"][graph.vertex(i)] = labels[i]
    
    v_start = 0

    try:
        while True:
            line = ad_matrix.readline().split()
            if not line:
                break
            for v_end in xrange(0, len(line)):
                if int(line[v_end]) is not 0:
                    graph.add_edge(graph.vertex(v_start), graph.vertex(v_end))
            assert (v_start < num_vertices)
            v_start += 1
    finally:
        ad_matrix.close()
        print 'The constructed graph is %s' % graph

def get_from_in_built_file(graph, in_built_filename):
    '''
    Derive the graph from a file of in-built filetype.

    @aattention: the file type must be one of the in-built data file types of graph_tool.

    @param graph: a graph object

    @param in_built_filename: a string
    '''
    graph = gt.load_from(in_built_filename)


def create_graph(graph, filename, filetype):
    '''
    Create a graph from a specified file.

    @attention: only adjacent matrix text file, xml file, and built-in file types of graph-tool are allowed.

    @param graph: Qgraph or Dgraph, graph object
    
    @param filename: a string specifying the filename

    @param filetype: a integer from {1, 2, 3} specifying the file types -- 1 denotes text file(adjacent matrix), 2 denotes XML file, 3 denotes in-built file types in graph_tool
    '''
    {
    1: lambda: get_from_adjacent_matrix,
    2: lambda: get_from_xml,
    3: lambda: get_from_in_built_file
    }[filetype]()(graph, filename)

    

def create_Qgraph():
    '''
    Create query graph.

    '''
    global Qgraph 
    data_file_name = raw_input("Input the query graph file name: ")
    file_type = 0
    while file_type not in {1, 2, 3}:
        print '''Please select from the following selections:
            [1] Text file
            [2] XML file
            [3] graph_tool library in-built types
        '''
        file_type = int(raw_input("Input the correct number of the type you selected:"))

    create_graph(Qgraph, data_file_name, file_type)


def create_Dgraph():
    '''
    Create data graph.
    '''
    global Dgraph
    data_file_name = raw_input("Input the data graph file name: ")
    file_type = 0
    while file_type not in {1, 2, 3}:
        print '''Please select from the following selections:
            [1] Text file
            [2] XML file
            [3] graph_tool library in-built types
        '''
        file_type = int(raw_input("Input the correct number of the type you selected:"))

    create_graph(Dgraph, data_file_name, file_type)

   

if __name__ == "__main__":
    curdir = os.getcwd()
    os.chdir(curdir)
    remfilelist = glob.glob('*.gz')

    print 'Delete the following files?'
    print remfilelist
    usercommand = raw_input('Input Y or N:')
    while usercommand <> 'Y' and usercommand <> 'N':
        usercommand = raw_input('Input Y or N:')
    if usercommand == 'Y':
        for name in remfilelist:
            os.remove(name)
               
    create_Qgraph()
    print 'The query graph is %s' %Qgraph
    print 'The list_properties of Qgraph are %s' %Qgraph.list_properties()
    Qgraph.save("Qgraph.xml.gz")

    create_Dgraph()
    print 'The data graph is %s' %Dgraph
    print 'The list_properties of Dgraph are %s' %Dgraph.list_properties()
    Dgraph.save("Dgraph.xml.gz")
    gt.graph_draw(Qgraph, vprops = {"label": Qgraph.vertex_properties["label"]}, output = "QueryGraph.png")
    gt.graph_draw(Dgraph, vprops = {"label": Dgraph.vertex_properties["label"]}, output = "DataGraph.png")
