package anran.hdcode2.sender

import scala.swing.SimpleSwingApplication
import scala.swing.MainFrame
import scala.swing.Button
import scala.swing.Dimension
import scala.swing.Graphics2D
import java.awt.Color
import scala.swing.FileChooser
import scala.swing.Component
import java.io.File
import anran.hdcode2.lib.GlobalProperty
import anran.hdcode2.lib.FileTransmitProperty
import anran.hdcode2.lib.FileTypes
import scala.actors.Actor
import java.awt.Image
import java.awt.image.BufferedImage
import java.util.ArrayList
import javax.imageio.ImageIO
import anran.hdcode2.zip.XZip
object SenderApplication extends SimpleSwingApplication{
  var bx=11
  var by=7
  var npar=3
  var xoffset=50
  var yoffset=20
  var symbolsize=8
  
  override def main(args:Array[String]){
    if(args.length>2){
      bx=Integer.parseInt(args(0))
      by=Integer.parseInt(args(1))
      npar=Integer.parseInt(args(2))
      xoffset=Integer.parseInt(args(3))
      yoffset=Integer.parseInt(args(4))
      symbolsize=Integer.parseInt(args(5))
    }
    top.open()
  }
  def top=new MainFrame {
    val imageList=new ArrayList[BufferedImage]()
      
    preferredSize=new Dimension(1440,1000)
    title="HDCode 2 Sender"
    this.background=Color.WHITE
    var started=false
    def isStarted()=started
    val panel=new scala.swing.Panel(){
      var current=0
      override def paintComponent(g:Graphics2D){
        if(isStarted)
        {
          g.drawImage(imageList.get(current), 0,0,null)
          current=(current+1)%imageList.size()
          Thread.sleep(100)
          this.repaint
        }
      }
      preferredSize=new Dimension(900,700)
      peer.setLocation(100, 100)
    }
    this.contents=panel
    val fc=new FileChooser()
    val res=fc.showOpenDialog(null)
    val th=new Thread(){
      var File:File=null
      def setFile(f:File)=File=f
      override def run(){
        val ftprop=new FileTransmitProperty(GlobalProperty.DataLinkProperty,FileTypes.PlainText,File.length().asInstanceOf[Int])
        val sender=FileTransmitApp.CreateAsSender(File.getAbsolutePath(),ftprop)
        sender.StartGenerating(new Actor(){
          def act()
          {
            while(true)
              receive{
              case (b:BufferedImage,id:Int)=>{
                //ImageIO.write(b,"PNG",new File(id+".png"))
                println(id+"")
                imageList.add(b)
                if(imageList.size()==ftprop.GetTotalWindowCount*ftprop.DataLinkProperty.RSStrengthFramesCount)
                {
                  started=true
                  panel.repaint
                  println("stop")
                  exit()
                }
              }
              
            }
          }
          start()
        })
      }
    }
    if(res==FileChooser.Result.Approve)
    {
      compress(fc.selectedFile.getAbsolutePath(),"temp.zip")
      th.setFile(new File("temp.zip"))
      th.start()
    }
    
    
  }
  
  private def compress(src:String,dest:String)={
    //val stream=new java.io.FileOutputStream(dest)
    //val zipstream=new java.util.zip.ZipOutputStream(stream)
    //val srcfile=new File(src)
    
    XZip.ZipFolder(src,dest)
    //zipstream.close()
    val file=new java.io.File(dest)
    file
  }
}