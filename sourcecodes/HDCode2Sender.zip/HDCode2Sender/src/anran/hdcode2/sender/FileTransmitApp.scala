package anran.hdcode2.sender

import anran.hdcode2.lib._
import scala.actors.Actor
import java.io.File
import java.io.IOException

trait HDCodeSenderApp{
  def StartGenerating(presentActor:Actor)
}
object FileTransmitApp{
  def CreateAsSender(src:String,ftProp:FileTransmitProperty)={
    
    new HDCodeSenderApp(){
      
      private def writeFileHeader(writer:Int=>Boolean){
        //1st byte
        writer(ftProp.FileType match{
          case FileTypes.ZIP=>1
          case FileTypes.PlainText=>2
          case FileTypes.PNGImage=>3
          case FileTypes.JPEGImage=>4
        })
        //2-4byte
        writer(ftProp.FileLength%256)
        writer(ftProp.FileLength/256%256)
        writer(ftProp.FileLength/65536%256)
        
        //5th byte
        writer((if(false)128 else 0)|ftProp.WindowId)
        
        for(i<-5 until ftProp.GetHeaderLength)
          writer(0)
      }
      
      def StartGenerating(presentActor:Actor){
        val dlProp=ftProp.DataLinkProperty
        val f=new File(src)
        if(!f.exists() || !f.canRead())throw new IOException()
        
        val instream=new java.io.FileInputStream(f)
        
        val cons=new FrameConstructor(dlProp)
        var isFirstBlock=true
        cons.RegisterBlockChangeListener((fid,bid)=>{
          isFirstBlock=(bid==0)
        })
        cons.RegisterWindowChangeListener(()=>{
          ftProp.WindowId+=1
        })
        //val rand=new Random()
        val outstream=cons.Start((bitmap,fid)=>{
          if(bitmap==null)presentActor!0
          else presentActor!(bitmap,fid)
        })
        var eof=false
        var byte=0
        while(!eof){
          byte=instream.read()
          if(byte<0){
            outstream(byte)
            eof=true
          }
          
          else{
            if(isFirstBlock){
              writeFileHeader(outstream)
              isFirstBlock=false
            }
            outstream(byte)
          }
        }
      }
    }
  }
}