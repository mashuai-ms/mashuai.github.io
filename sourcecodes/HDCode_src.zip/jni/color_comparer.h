

#ifndef COLOR_COMPARER_H_
#define COLOR_COMPARER_H_

#include <assert.h>
#include "structures.h"

//#define NULL 0

class color_comparer{
private:
	int* colors;
	int color_count;
	inline int abs(int x){
		return x>=0?x:-x;
	}
public:
	color_comparer(){
		colors=NULL;
		color_count=0;
	}
	void set_palette(int* colors,int color_count){
		this->colors=colors;
		this->color_count=color_count;
	}
	int find_nearest(int color){
		assert(colors!=NULL);
		int min_dist=1e9;
		int min_dist_id=0;
		for(int i=0;i<color_count;i++){
			int Ydelta=abs((color>>16)-(colors[i]>>16));
			int Udelta=abs(((color>>8)&255)-((colors[i]>>8)&255));
			int Vdelta=abs((color&255)-(colors[i]&255));

			int dist=Ydelta+Udelta+Vdelta;
			if(dist<min_dist){
				min_dist=dist;min_dist_id=i;
			}
		}
		return min_dist_id;
	}

	//not implemented
	int find_nearest_soft(int color, double& prob){
		return 0;
	}
};




#endif /* COLOR_COMPARER_H_ */
