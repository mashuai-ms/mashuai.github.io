package anran.hdcode2

class Test(a:Int) {
	def f="asd";
}