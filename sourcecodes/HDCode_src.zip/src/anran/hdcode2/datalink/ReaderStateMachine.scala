package anran.hdcode2.datalink

import anran.hdcode2.library.CaptureProperty
import android.graphics.Point
import anran.hdcode2.physical.PatternLocater
import anran.hdcode2.physical._
import anran.hdcode2.physical.BlockScanner
import anran.hdcode2.library.PixelReader
import anran.hdcode2.library.DataLinkProperty
import anran.hdcode2.physical.SquareLocater
import anran.hdcode2.application.HDCodeReceiverApp
import anran.hdcode2.physical.PatternLocater
import android.util.Log
import anran.hdcode2.PointsView
import anran.hdcode2.library.Utils
import scala.actors.Actor
import anran.hdcode2.library.YUVColor
import anran.hdcode2.GlobalProperty
import anran.hdcode2.NativeBridge


class ReaderStateMachine(capProp:CaptureProperty,app:HDCodeReceiverApp) {
  //PointsView: Only for test
  var pview:PointsView=null
  def addp(x:Int,y:Int)=if(pview==null)Unit else pview.add(x, y)
  def addp(p:Point):Unit=addp(p.x,p.y)
  def clearp=if(pview==null)Unit else pview.clear
  //end
  
  //A frame for storing frame data
  class ReceiveFrame(dlProp:DataLinkProperty){
    val Blocks=Array.fill(dlProp.PhysicalProperty.BlockAvailableCount){new BlockState(dlProp,null)}  
  }
  

  var started=false
  
  /**
   * Start receiving
   */
  def Start(){
    NativeBridge.startdecode(GlobalProperty.PhysicalProperty.BlockSize,GlobalProperty.PhysicalProperty.BlockSize,
        GlobalProperty.PhysicalProperty.BlockCountX,GlobalProperty.PhysicalProperty.BlockCountY,
        capProp.Width,capProp.Height)
    Utils.openLog
      
    started=true
  }
  /**
   * Stop receiving
   */
  def Stop(){
    Utils.closeLog
      
    started=false
  }
  /**
   * Receive raw data from camera
   */
  def HandleFrameData(data:Array[Byte]):()=>Unit={
    //FOR EVALUATION
    var succblock=0
    var failblock=0
    
    var dlProp:DataLinkProperty=GlobalProperty.DataLinkProperty
    var window:Array[ReceiveFrame]=Array.fill(256){new ReceiveFrame(dlProp)}
    app.ReceiveMessage(GlobalProperty.DataLinkProperty)

    //fundamental functions
    def abs(x:Int)=if(x<0) -x else x
    def timeused(f:()=>Unit)={
      val time=System.currentTimeMillis()
      f()
      System.currentTimeMillis()-time
    }
    //end
    
    //position related functions
    
    //data related functions
    def isnear(id1:Int,id2:Int)={
      val c=id2-id1
      if(c==1||c==0)1
      else if(c== -3)0
      else if(c>0)-1
      else -2
    }
    
    def copyBlock(dest:BlockState,src:BlockState){
      var i=0
      while(i<src.Data.length){
        dest.Data(i)=src.Data(i)
        i=i+1
      }
    }
    def addBlock(dest:BlockState,src:BlockState){
      var i=0
      while(i<dest.Data.length){
        dest.Data(i)^=src.Data(i)
        i=i+1
      }
    }
    //end
    
        //EC Layer
    
    object ECBuffer2{
      val bmap=Array.fill(256,dlProp.PhysicalProperty.BlockAvailableCount){false}
      val finished=Array.fill(256){false}
      def emit(fid:Int,bid:Int,wid:Int){
        if(fid==dlProp.RSStrengthFramesCount-1)return
        for(i<-dlProp.InterBlockParity)
          if(bid==i(i.length-1))return
          
        Utils.debuginfo("Emit", fid+" "+bid+" "+wid, 0)
        app.ReceiveData(window(fid+wid*dlProp.RSStrengthFramesCount).Blocks(bid), fid, bid, wid)
      }
      var last_fid= -1
      
      var log_old_throughput=0
      var log_received_throughput=0
      var log_received_blocks=0
      var log_goodput=0
      var log_old_goodput=0
      //var log_old_failed_blocks=0
      
      var init_time=System.currentTimeMillis()
      var prev_time=System.currentTimeMillis()
      
      def BlockReady(fid:Int,bid:Int){
        //if(bmap(fid)(bid))return
        if(bid<dlProp.PhysicalProperty.BlockAvailableCount-dlProp.InterBlockECCount&&fid%dlProp.RSStrengthFramesCount<dlProp.RSStrengthFramesCount-1){
          
          if(!bmap(fid)(bid)){
            log_received_blocks+=1
            log_goodput+=33-dlProp.RSStrengthInFrame*2
          }
        }
        
        bmap(fid)(bid)=true
        last_fid=fid
        emit(fid%dlProp.RSStrengthFramesCount,bid,fid/dlProp.RSStrengthFramesCount)
      }
      
      def InterBlockEC(fid:Int){
        def layeri(i:Int){
          var ecount=0
          var epos=0
          for(j<-dlProp.InterBlockParity(i)){
            if(!bmap(fid)(j)){
              ecount+=1
              epos=j
            }
            
          }
          if(ecount==1){
            
            //correctable
            
            Log.i("InterBlockEC", "Take effect! "+fid+" "+epos)
            val dest=window(fid).Blocks(epos)
            val dlen=dest.Data.length
            for(j<-0 until dlen)dest.Data(j)=0
            for(j<-dlProp.InterBlockParity(i)){
              if(j!=epos){
                addBlock(dest,window(fid).Blocks(j))
                dest.Data(0)=window(fid).Blocks(j).Data(0)
              }
            }
            BlockReady(fid,epos)
          
            //only affect last layer
            if(i!=0)
              layeri(i-1)
          
          }
          else{}
        }
        
        (0 until dlProp.InterBlockECCount).map(i=>layeri(i))
      }
      def InterFrameEC(wid:Int,bid:Int){
        var vacancy=0
        for(i<-wid*dlProp.RSStrengthFramesCount until (wid+1)*dlProp.RSStrengthFramesCount-1)
          if(!bmap(i)(bid))vacancy+=1
        if(vacancy!=1|| !bmap((wid+1)*dlProp.RSStrengthFramesCount-1)(bid))return
        
        var i=0
        while(i<dlProp.RSStrengthFramesCount&&bmap(wid*dlProp.RSStrengthFramesCount+i)(bid))i+=1
        val dest=window(i+dlProp.RSStrengthFramesCount*wid).Blocks(bid)
        val dlen=dest.Data.length
        for(j<-0 until dlen)dest.Data(j)=0
            
        for(j<-0 until dlProp.RSStrengthFramesCount)
          if(j!=i){
            addBlock(dest,window(j+wid*dlProp.RSStrengthFramesCount).Blocks(bid))
            dest.Data(0)=j+dlProp.RSStrengthFramesCount*wid
          }
        Log.i("InterFrameEC","Take effect! "+wid+" "+i+" "+bid)
        BlockReady(i+wid*dlProp.RSStrengthFramesCount,bid)
      }
      
      
      def EC(){
        
        var log_info=""
        val ti=System.currentTimeMillis()-init_time
        val tp=System.currentTimeMillis()-prev_time
        if(ti!=0&&tp!=0){
          log_info+=((log_goodput-log_old_goodput)/tp.asInstanceOf[Double])+"\t"
          log_info+=(log_goodput)/ti.asInstanceOf[Double]+"\t"
          log_info+=log_received_blocks +"\t"
          log_old_goodput=log_goodput
          
          Utils.writeLog(log_info)
          prev_time=System.currentTimeMillis()
        }
        
        
        if(last_fid<0)return
        val window=last_fid/dlProp.RSStrengthFramesCount
        
        def check_frame(fid:Int){
          InterBlockEC(fid)
        }
        def check_window(wid:Int,bid:Int){
          InterFrameEC(wid,bid)
        }
        
        check_frame(last_fid)
        if(last_fid>0)
          check_frame(last_fid-1)
        for(i<-0 until dlProp.PhysicalProperty.BlockAvailableCount)
          check_window(window,i)
      }
    }
    
    def checksum(b:BlockState)={
      var t=0
      for(i<-0 until b.Data.length-dlProp.RSStrengthInFrame*2-1)
        t=(t+b.Data(i)+1)%256
      t==b.Data(b.Data.length-dlProp.RSStrengthInFrame*2-1)
    }
    
    val data_buffer=new BlockState(dlProp,null)
    
    def callNative(){
      val tick=System.currentTimeMillis()
      NativeBridge.pushdata(data)
      while(true){
        val res=NativeBridge.pulldata(dlProp.RSStrengthInFrame*2,data_buffer.Data)
        if(res== -1){
          ECBuffer2.EC()
          Log.i("decode_time",System.currentTimeMillis()-tick+" ")
          NativeBridge.releasedata(data)
          return
        }
        val bfid=data_buffer.Data(0)
        if(checksum(data_buffer)){
          copyBlock(window(bfid).Blocks(res),data_buffer)
          ECBuffer2.BlockReady(bfid,res)
        }
      }
      NativeBridge.releasedata(data)
    }
    
    val point_xs=new Array[Int](300)
    val point_ys=new Array[Int](300)
    
    //new handler
    def resnew():Unit={
      clearp;
      if(started){
        callNative()
        val count=NativeBridge.getpoints(point_xs,point_ys);
        for(i<-0 until count)addp(point_xs(i),point_ys(i));
      }
    }
    
    
    
    
    //result handler
      ()=>{resnew();if(pview!=null)pview.invalidate()}
  }
}