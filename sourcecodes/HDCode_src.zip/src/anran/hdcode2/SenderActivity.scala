package anran.hdcode2

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.view.Window
import android.content.Intent

class SenderActivity extends Activity{
  override def onCreate(bundle:Bundle)
  {
    super.onCreate(bundle)
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
    requestWindowFeature(Window.FEATURE_NO_TITLE)
    
    setContentView(R.layout.activity_sender)
    
    
    startActivityForResult(new Intent(this,classOf[FileList]),0)
    
  }
  protected override def onActivityResult(reqCode:Int,resCode:Int,data:Intent){
    val fname:String=data.getExtras().get("filename").asInstanceOf[String]
    val th=new Thread(){
      override def run(){
        Thread.sleep(3000)
        val pv=findViewById(R.id.view1).asInstanceOf[PresentView]
        pv.Start(fname, GlobalProperty.DataLinkProperty)
      }
    }
    th.start()
  }
}