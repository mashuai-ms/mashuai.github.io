package anran.hdcode2

import android.view.SurfaceView
import android.content.Context
import android.util.AttributeSet
import android.view.SurfaceHolder
import anran.hdcode2.library.PresentProperty
import anran.hdcode2.application.RandomFillApp
import android.graphics.Bitmap
import scala.actors.Actor
import anran.hdcode2.application.FileTransmitApp
import anran.hdcode2.library.FileTransmitProperty
import anran.hdcode2.library.DataLinkProperty
import anran.hdcode2.zip.XZip
import anran.hdcode2.library.FileTypes
import anran.hdcode2.physical.Frame
import java.io.File
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Log
import android.app.ActivityManager

class PresentView(context:Context,attrs:AttributeSet) extends SurfaceView(context,attrs) {
  var holder:SurfaceHolder=this.getHolder()
  private var msgActor:Actor=null
  def SetMessageOutput(output:Actor){
    this.msgActor=output
  }
  private def compress(src:String,dest:String)={
    //val stream=new java.io.FileOutputStream(dest)
    //val zipstream=new java.util.zip.ZipOutputStream(stream)
    //val srcfile=new File(src)
    
    XZip.ZipFolder(src,dest)
    //zipstream.close()
    val file=new java.io.File(dest)
    file
  }
  private var cont=false
  def Start(src:String,dlProp:DataLinkProperty)
  {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE).asInstanceOf[ActivityManager];
    val zippath=new java.io.File("/sdcard/temp.zip").getAbsolutePath()
    val file=compress(src,zippath)
    val ftProp=new FileTransmitProperty(dlProp,FileTypes.ZIP,file.length().asInstanceOf[Int])
    val ftapp=FileTransmitApp.CreateAsSender(file.getAbsolutePath(), ftProp)
    
    val bitmapQueue=Array.fill(dlProp.RSStrengthFramesCount){new java.util.ArrayList[Bitmap]()}
    val currentWindow=Array.fill(dlProp.RSStrengthFramesCount){0}
    def startPresent(){
      val th=new Thread(){
        var currfid=0
        override def run(){
          Thread.sleep(1000)
          while(cont){
            Thread.sleep(1000/dlProp.PhysicalProperty.PresentProperty.FPS)
            //Log.i("present",currfid+"")
            val canvas=holder.lockCanvas()
            canvas.drawColor(Color.WHITE)
            val time=System.currentTimeMillis()
            canvas.drawBitmap(bitmapQueue(currfid).get(currentWindow(currfid)), 0, 0, null)
            //Log.i("loadtime",System.currentTimeMillis()-time+"")
            currentWindow(currfid)+=1
            if(currentWindow(currfid)==bitmapQueue(currfid).size())currentWindow(currfid)=0
            currfid=(currfid+1)%dlProp.RSStrengthFramesCount
            holder.unlockCanvasAndPost(canvas)
          }
        }
      }
      th.start()
    }
    
    cont=true
    ftapp.StartGenerating(new Actor(){
      def act(){
        while(cont){
          receive{
            case (dest:Bitmap,fid:Int)=>{
              bitmapQueue(fid).add(dest)
              
              Log.i("receive",fid+"")
            }
          }
      }
      }
      this.start
    })
    startPresent()
  }
  def End(){
    cont=false
    
  }
}