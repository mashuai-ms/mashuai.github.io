package anran.hdcode2.application

import anran.hdcode2.physical.PatternLocater
import anran.hdcode2.library.CaptureProperty
import anran.hdcode2.physical.SquareLocater
import anran.hdcode2.physical.{LT,RT,LB,RB}
import anran.hdcode2.physical.BlockScanner
import anran.hdcode2.GlobalProperty
import anran.hdcode2.library.PixelReader
import anran.hdcode2.physical.BlockState
import anran.hdcode2.datalink.ReaderStateMachine
import android.util.Log
import anran.hdcode2.library.DataLinkProperty
import anran.hdcode2.PointsView

class TestApp(data:Array[Byte],pview:PointsView) extends HDCodeReceiverApp {
  def GetTestResult()=diff
  val machine=new ReaderStateMachine(GlobalProperty.CaptureProperty,this)
  machine.pview=pview
  
  machine.Start()
  
  val handler=machine.HandleFrameData(data)
  
  var error=false
  def PushOriginalData(){
    for(i<-0 until 10){
      handler()
      if(allReceived())return;
    }
      
  }
  def ReceiveData(blockdata:BlockState,frameId:Int,blockId:Int,wid:Int){
    
  }
  val phProp=GlobalProperty.PhysicalProperty
  val diff:Array[Array[Array[Int]]]=Array.fill(phProp.BlockCountY,phProp.BlockCountX){null}
  private def allReceived():Boolean={
    var nullcount=0
    for(i<-0 until phProp.BlockCountY)
    for(j<-0 until phProp.BlockCountX){
      if(diff(i)(j)==null)nullcount+=1 
      }
    Log.i("rec",nullcount+"")
    if(nullcount>1)return false
    
    return true
  }
  def ReceiveMessage(msg:Any){
    msg match{
      case (y:Int,x:Int,arr:Array[Int])=>{
        diff(y)(x)=arr 
        for(i<-0 until arr.length)
          if(i%4!=arr(i))arr(i)=1
          else arr(i)=0
          
      }
      case dlProp:DataLinkProperty=>{Log.i("dlprop",dlProp.PhysicalProperty.BlockCountX+" "+dlProp.PhysicalProperty.BlockCountY)}
      case _=>{}
    }
  }
}