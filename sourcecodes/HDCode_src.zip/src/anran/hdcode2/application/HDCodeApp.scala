package anran.hdcode2.application

import scala.actors.Actor
import anran.hdcode2.physical.BlockState
import anran.hdcode2.library.PresentProperty
import anran.hdcode2.library.DataLinkProperty

trait HDCodeSenderApp{
  def StartGenerating(presentActor:Actor)
}
trait HDCodeReceiverApp{
  def PushOriginalData()
  def ReceiveData(blockdata:BlockState,frameId:Int,blockId:Int,wid:Int)
  def ReceiveMessage(msg:Any)
}
