package anran.hdcode2.application

import anran.hdcode2.library.PresentProperty
import anran.hdcode2.physical.BlockState
import java.io.File
import java.io.IOException
import scala.actors.Actor
import anran.hdcode2.datalink.FrameConstructor
import anran.hdcode2.library.DataLinkProperty
import anran.hdcode2.library.FileTransmitProperty
import anran.hdcode2.library.FileTypes
import anran.hdcode2.datalink.ReaderStateMachine
import anran.hdcode2.library.CaptureProperty
import android.util.Log
import java.util.Random
import android.graphics.Point
import anran.hdcode2.PointsView
import anran.hdcode2.library.Utils
import anran.hdcode2.GlobalProperty

object FileTransmitApp{
  def CreateAsSender(src:String,ftProp:FileTransmitProperty)={
    
    new HDCodeSenderApp(){
      
      private def writeFileHeader(writer:Int=>Boolean){
        //1st byte
        writer(ftProp.FileType match{
          case FileTypes.ZIP=>1
          case FileTypes.PlainText=>2
          case FileTypes.PNGImage=>3
          case FileTypes.JPEGImage=>4
        })
        //2-4byte
        writer(ftProp.FileLength%256)
        writer(ftProp.FileLength/256%256)
        writer(ftProp.FileLength/65536%256)
        
        //5th byte
        writer((if(false)128 else 0)|ftProp.WindowId)
        Log.i("fileheader",ftProp.WindowId+"")
        for(i<-5 until ftProp.GetHeaderLength)
          writer(0)
      }
      
      def StartGenerating(presentActor:Actor){
        val dlProp=ftProp.DataLinkProperty
        val f=new File(src)
        if(!f.exists() || !f.canRead())throw new IOException()
        
        val instream=new java.io.FileInputStream(f)
        
        val cons=new FrameConstructor(dlProp)
        var isFirstBlock=true
        cons.RegisterBlockChangeListener((fid,bid)=>{
          isFirstBlock=(bid==0)
        })
        cons.RegisterWindowChangeListener(()=>{
          Log.i("fileheader","WID++:"+(ftProp.WindowId+1))
          ftProp.WindowId+=1
        })
        val rand=new Random()
        val outstream=cons.Start((bitmap,fid)=>{
          presentActor!(bitmap,fid)
        })
        var eof=false
        var byte=0
        while(!eof){
          byte=instream.read()
          if(byte<0){
            outstream(byte)
            eof=true
          }
          
          else{
            if(isFirstBlock){
              writeFileHeader(outstream)
              isFirstBlock=false
            }
            outstream(byte)
          }
        }
      }
    }
  }
  def CreateAsReceiver(capProp:CaptureProperty,destFolder:String,tmpPath:String,prog:Double=>Unit,msgActor:Actor,data:Array[Byte],onFinish:String=>Unit,pview:PointsView)=new HDCodeReceiverApp(){
    private var storage:PersistantStorage=null
    private val stateMachine=new ReaderStateMachine(capProp,this)
    stateMachine.pview=pview
    stateMachine.Start
    val handler=stateMachine.HandleFrameData(data)
    private var dlProp:DataLinkProperty=GlobalProperty.DataLinkProperty
    private var ftProp:FileTransmitProperty=null
    private var blockWinId:Array[Int]=null
    private var totalBlocks:Array[Boolean]=null
    private val receivedBlockCount=new java.util.concurrent.atomic.AtomicInteger(0)
    private val progress=prog
    
    def PushOriginalData()=handler()
    
    private def readFileHeader(dlProp:DataLinkProperty,b:BlockState):FileTransmitProperty={
      val ft=b.Data(1) match{
        case 1=>FileTypes.ZIP
        case 2=>FileTypes.PlainText
        case 3=>FileTypes.PNGImage
        case 4=>FileTypes.JPEGImage
        case _=>Utils.debuginfo("FTProp", b.Data(1)+" ", null)
      }
      if(ft==null)null else{
        val fl=(b.Data(2)|(b.Data(3)<<8)|(b.Data(4)<<16))
        val err=(b.Data(5)>128)
        val wid=(b.Data(5)&127)
        new FileTransmitProperty(dlProp,ft,fl,wid)
      }
    }
    
    private def readWindowId(b:BlockState)=b.Data(5)&127
    
    private var currentWid= -1
    private var currentWindowId=0
    
    def ReceiveData(blockdata:BlockState,frameId:Int,blockId:Int,wid:Int){
      @inline def getDelta(standard:Int,n:Int,r:Int)={
        if(standard-n==0)0
        if(standard-n==r-1)-1
        else if(standard-n==1-r)1
        else if(standard-n==1||standard-n== -1)standard-n
        else -2
      }
      if(ftProp!=null){
        //if(blockId==0){
          //update window id
        //  currentWindowId=readWindowId(blockdata)
        //  currentWid=wid
        //  Log.i("ReceiveData","UpdateFT: "+currentWindowId+" "+currentWid)
        //}
        var cwid=wid//(currentWindowId+(wid-currentWid)+ftProp.GetTotalWindowCount)%ftProp.GetTotalWindowCount
        //if(cwid<0)Log.i("ReceiveData",currentWindowId+"+"+wid+"-"+currentWid)
        val bid=ftProp.GetBlockId(cwid, frameId, ftProp.blockMap(blockId))
        if(bid>=ftProp.GetTotalBlockCount)return
        
        if(totalBlocks(bid)==false){
          totalBlocks(bid)=true
          
          
          
          storage.Write(cwid,frameId,ftProp.blockMap(blockId),blockdata)
          val newcount=receivedBlockCount.incrementAndGet()
          prog(newcount/ftProp.GetTotalBlockCount.asInstanceOf[Double])
          if(newcount>ftProp.GetTotalBlockCount-40){//Distribution
            var str=""
           // if(false){
              for(i<-0 until totalBlocks.length)
                if(!totalBlocks(i))str+=(i+" ")
              Log.i("distribution",totalBlocks.length+": "+str)
           // }
          }
        }
        
        if(receivedBlockCount.compareAndSet(ftProp.GetTotalBlockCount,ftProp.GetTotalBlockCount+1)){
          val finalpath=destFolder+"/dest.zip"//+ftProp.getExtension()
          if(storage.StopAndSave(finalpath)){
            stateMachine.Stop
            if(onFinish!=null)onFinish(finalpath)
          }
        }
      }
      else if(blockId==0){
        //parse the fileTransmitProperty
        val nftProp=readFileHeader(dlProp,blockdata)
        if(nftProp==null){
          Utils.debuginfo("FTProp","Unrecognized ftprop",Unit) 
          return
        }
        else Utils.debuginfo("FTProp","FTProp: "+nftProp.FileLength+" "+nftProp.GetTotalBlockCount+" "+nftProp.blockMap(dlProp.PhysicalProperty.BlockAvailableCount-1),0)
        storage=new PersistantStorage(nftProp, "/sdcard/tempcode")
        
        totalBlocks=Array.fill(nftProp.GetTotalBlockCount){false}
        //currentWid=wid
        //currentWindowId=nftProp.WindowId
        ftProp=nftProp
      }
    }
    
    def ReceiveMessage(msg:Any):Unit=if(msg==null)return else{
     Log.i("Message received",msg.toString) 
     msg match{
      case (dlProp:DataLinkProperty)=>{
        Log.i("dlProp received", "..");
        if(this.dlProp==null){
          Log.i("dlProp received", "...");
          this.dlProp=dlProp 
          blockWinId=Array.fill(dlProp.PhysicalProperty.BlockCountX*dlProp.PhysicalProperty.BlockCountY){-1}
        }
      }
      case p:Point=>{
        msgActor!p
      }
      case _=>{}
    }
    }
  }
}