package anran.hdcode2

import android.view.View
import android.net.Uri
import android.view.SurfaceView
import android.hardware.Camera
import android.view.SurfaceHolder
import android.util.Log
import android.widget.TextView
import android.widget.FrameLayout
import android.graphics.Color
import android.graphics.Point
import anran.hdcode2.application.FileTransmitApp
import anran.hdcode2.library.CaptureProperty
import scala.actors.Actor
import anran.hdcode2.application.HDCodeReceiverApp
import anran.hdcode2.physical.PatternLocater
import anran.hdcode2.application.TestApp
import anran.hdcode2.library.PixelReader
import anran.hdcode2.zip.XZip
import android.app.Activity
import android.os.Bundle
import android.content.Intent 

class CameraView(context:android.content.Context,attset:android.util.AttributeSet) extends SurfaceView(context,attset) with SurfaceHolder.Callback{
  var camera:Camera=null
  val surfaceHolder = getHolder();
  surfaceHolder.addCallback(this);
  val buffer=new Array[Byte](720*1280*6)
  var started=false
  
  var activity:Activity=null
  def setActivity(act:Activity){activity=act}

  def testSpeed(data:Array[Byte])={
    val preader=new PixelReader(data,GlobalProperty.CaptureProperty)
    val dataarr=Array.fill(GlobalProperty.CaptureProperty.Height,GlobalProperty.CaptureProperty.Width)(0)
    val currt=System.currentTimeMillis()
    var i=0
    var j=0
    while(i<GlobalProperty.CaptureProperty.Height){
      j=0
      while(j<GlobalProperty.CaptureProperty.Width)
      {
        val black=preader.GetPixelY(j, i)
        if(black<60)
          dataarr(i)(j)=1
          else
            dataarr(i)(j)=0
        j+=2
      }
      i+=2
    }
    Log.i("IterTime",System.currentTimeMillis()-currt+"")
    dataarr
  }
  override def surfaceChanged(holder:SurfaceHolder,format:Int, width:Int,height:Int){
    camera.setPreviewDisplay(surfaceHolder)
    val param=camera.getParameters()
    param.setPreviewSize(1280,720)
    param.setRecordingHint(true)
    param.set("ISO-value", "ISO1600")
    camera.setParameters(param)
    camera.addCallbackBuffer(buffer)
    camera.setPreviewCallbackWithBuffer(new android.hardware.Camera.PreviewCallback(){
      override def onPreviewFrame(data:Array[Byte],camera:Camera){
        camera.addCallbackBuffer(buffer)
        if(started){
          if(GlobalProperty.TESTFRAME){
            //test speed
            testSpeed(data)
            val app2=new TestApp(data,pview)
            app2.PushOriginalData
            val res=app2.GetTestResult
            
            //do total BER rate
            var fm=0
            var fz=0
            for(a<-res)
              for(b<-a)
                if(b!=null){
                  for(c<-b){
                    fm+=1
                    if(c!=0)fz+=1
                  }
                }
            Log.i("Total BER:",fz+"/"+fm)
            
            //do hotspot
            var str:String=""
            var i=0
            for(a<-res){
              
              for(b<-a)
                if(b!=null){
                  str=""
                  var fm=0
                  var fz=0
                  for(i<-0 until b.length){
                    fm+=1
                    if(b(i)!=0)str+=i+" "
                  }
                  //str+=(fz.asInstanceOf[Double]/fm)+", "
                  
                  Log.i("Err dist "+i+": ",str)
                  i+=1
                }
            }
            started=false
          }
          else{
            app.PushOriginalData()
            updateUI()
        
          }
        }
      }
    })
    
    camera.startPreview()
  }
  override def surfaceCreated(holder:SurfaceHolder){
    camera=Camera.open()
  }
  override def surfaceDestroyed(holder:SurfaceHolder){
    camera.stopPreview()
    camera.release()
  }
  private var txtMsg:TextView=null
  private var pview:PointsView=null
  private val capProp=new CaptureProperty(1280,720)
  private var progress:Double=0
  private var currstate:Int=0
  private var centerx=0
  private var centery=0
  private var app:HDCodeReceiverApp=null
  def Start(layout:FrameLayout){
    txtMsg=new TextView(layout.getContext(),attset)
    txtMsg.setText("HHHHH")
    txtMsg.setTextColor(Color.GREEN)
    
    pview=new PointsView(layout.getContext(),attset)
    app=FileTransmitApp.CreateAsReceiver(capProp, "/sdcard/temp/", "/sdcard/tmp/", d=>{
        progress=d
        //Log.i("progress",d+"")
      },new Actor(){
        def act(){
          while(true){
            receive{
              case p:Point=>pview.add(p)
            }
          }
        }
      start()
    },buffer,(path:String)=>{
      var image:String=null
      try{
        image=XZip.UnZipFolder(path, "/sdcard/HDCodeReceived")
      }catch{
        case t:Throwable=>{Log.e("Zip Error",t.getMessage())}
      }
      if(image==null){
      val bundle=new Bundle()
      bundle.putString("Receive", "")
      val intent=new Intent(activity,classOf[FileList])
      intent.putExtras(bundle)
      activity.startActivity(intent)
      }
      else{
        val show=new Intent(Intent.ACTION_VIEW);
        show.setDataAndType(Uri.parse("file://"+image), "image/*");
        activity.startActivity(show);
      }
    },pview)
    layout.addView(txtMsg)
    layout.addView(pview)
    
    camera.autoFocus(new android.hardware.Camera.AutoFocusCallback(){
      def onAutoFocus(ok:Boolean,c:Camera){
        started=true
      }
    })
  }
  private def updateUI(){
    txtMsg.setText("current state: "+currstate+", current progress: "+progress)
    pview.invalidate()
    //pview.clear
  }
  
}