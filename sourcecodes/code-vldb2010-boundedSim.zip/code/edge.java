package Graph;

import java.io.Serializable;

import org.jgraph.graph.DefaultEdge;

public class edge extends DefaultEdge implements Serializable{
	
    
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
        private short bound;   //  indicate distance bound


	public edge(){
            this.bound = 1;
	}

        public edge(short b){
            this.bound = b;
        }
        
	public edge(String fn, String tn){
            this.setSource(fn);
            this.setTarget(tn);
            this.bound = 1;
	}
        
        public edge(String fn, String tn, int b){
            this.setSource(fn);
            this.setTarget(tn);
            this.bound = 1;
        }
	
	
	public boolean equals(Object o){
		if(this == o){
			return true;
		}
		else if(! (o instanceof edge) || o==null){
			return false;
		}
		else if(this.getSource().toString().equals(((DefaultEdge) o).getSource().toString()) && this.getTarget().toString().equals(((DefaultEdge) o).getTarget().toString())){
			return true;
		}
		else{
			return false;
		}
	}
	
        
	public int hashCode(){
		int result;
		result = (this.getSource().toString() == null?0:this.getSource().toString().hashCode());
		result = 37*result + (this.getTarget().toString() == null?0:this.getTarget().toString().hashCode());
		return result;
	}
        
        public void setbound(short b){
            this.bound = b;
        }
	
        public short getbound(){
            return this.bound;
        }
	
}
