package Graph;


import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

import org.jgrapht.DirectedGraph;
import org.jgrapht.Graph;
import org.jgrapht.alg.StrongConnectivityInspector;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.traverse.TopologicalOrderIterator;


public class cg_graph extends DefaultDirectedWeightedGraph<String, edge> implements Serializable{

	public String gfilename = "";
	public StrongConnectivityInspector<String, edge> sccIns;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public cg_graph() {
		super(edge.class);
	}
	

	/**
	 *  transitive closure computing
	 *  return a hashmap with key:nodesets structure
	 */	
	public HashMap<String,HashSet<String>> transitiveclosure(){
		HashMap<String, HashSet<String>> rNodeset = new HashMap<String, HashSet<String>>();
		for(String n:this.vertexSet()){
			HashSet<String> hset = (HashSet<String>) this.bfsreturn(n).keySet();
			rNodeset.put(n, hset);
			System.out.println(n+" reachable nodes number " + rNodeset.get(n).size());
		}
		return rNodeset;
	}
	
	/**
	 *  for each node, compute reachable descents and ancestors  
	 */
	public Vector<HashMap<String, HashSet<String>>> preProcess(){
		HashMap<String, HashSet<String>> reachAncestor1 = new HashMap<String, HashSet<String>>();
		HashMap<String, HashSet<String>> reachDescendent1 = new HashMap<String, HashSet<String>>();
		TopologicalOrderIterator<String, edge> toi = new TopologicalOrderIterator<String, edge>(this);
		Stack<String> reverseOrder = new Stack<String>();
		HashSet<String> cancc = new HashSet<String>();
		HashSet<String> cdess = new HashSet<String>();
		while(toi.hasNext()){
			String currentnode = toi.next();
			reverseOrder.push(currentnode);
			if(this.inDegreeOf(currentnode)==0){
				reachAncestor1.put(currentnode, null);
			}
			cancc = reachAncestor1.get(currentnode);
			for(edge e:this.outgoingEdgesOf(currentnode)){
				String endnode = (String) e.getTarget();
				HashSet<String> vec = reachAncestor1.get(endnode);
				if(vec==null){
					vec = new HashSet<String>();
					vec.add(currentnode);					
					if(cancc!=null){
						System.out.println("00: "+cancc.size());
						vec.addAll(cancc);
					}
					reachAncestor1.put(endnode, vec);
					vec = null;
				}
				else{
					vec.add(currentnode);
					if(cancc!=null){
						System.out.println("01: "+cancc.size());
						vec.addAll(cancc);
					}
					reachAncestor1.put(endnode, vec);
					cancc = null;
				}
			}
			cancc = null;
		}

		while(!reverseOrder.empty()){
			String currentnode = reverseOrder.pop();
			if(this.outDegreeOf(currentnode)==0){
				reachDescendent1.put(currentnode, null);
			}
			cdess = reachDescendent1.get(currentnode);
			for(edge e:this.incomingEdgesOf(currentnode)){
				String startnode = (String) e.getSource();
				HashSet<String> vec = reachDescendent1.get(startnode);
				if(vec==null){
					vec = new HashSet<String>();
					vec.add(currentnode);
					if(cdess!=null){
						if(cdess.size()>10000){
							System.out.println("-----------------------"+currentnode+"-----------------------");
						}
						vec.addAll(cdess);
					}
					reachDescendent1.put(startnode, vec);
					vec = null;
				}
				else{
					vec.add(currentnode);
					if(cdess!=null){
						System.out.println("11: "+cdess.size());
						vec.addAll(cdess);
					}
					reachDescendent1.put(startnode, vec);
					cancc = null;
				}
			}
			cdess = null;
		}
		Vector<HashMap<String, HashSet<String>>> result = new Vector<HashMap<String, HashSet<String>>>();
		result.add(reachAncestor1);		// 0:ancestor
		result.add(reachDescendent1);	// 1:descendent
		return result;
	}

	


	/**
	 *  cast a default graph to directed graph
	 */
	public DirectedGraph<String, edge> Cast2DG(){ 
		DirectedGraph<String, edge> DG = 
			new DefaultDirectedGraph<String, edge>(edge.class);
			for(String n: this.vertexSet())
				DG.addVertex(n);
			for(edge e:this.edgeSet()){
				String from = (String) e.getSource();
				String to = (String) e.getTarget();
				DG.addEdge(from,to,e);
			}
			return DG;
	}
	
	
	/**	
	 *	expands an scc node into a node set
	 */
	public HashSet<String> expSCC(String sccnode){
		String s = sccnode;
		Vector<String> nids = createVectorFromString(s,"_");
		HashSet<String> nset = new HashSet<String>();
		for(String id: nids){
			nset.add(id);
		}
		return nset;
	}	
	
	
	/**
	 *  sort the node in descending order according to degree
	 * @param g
	 * @return
	 */
	public Vector<String> sortwithdegree(){
		Vector<String> nodeSet = new Vector<String>();
		nodeSet.addAll(this.vertexSet());
		Comparator<String> comparator = new nodeComparator(this);
		Collections.sort(nodeSet, comparator);
		return nodeSet;		
	}
	
	/**
	 *  sort the node in descending order according to degree
	 * @param hs : hashset as data structure
	 * @return
	 */
	public Vector<String> sortwithdegree(HashSet<String> hs){
		Vector<String> nodeSet = new Vector<String>();
		nodeSet.addAll(hs);
		Comparator<String> comparator = new nodeComparator(this);
		Collections.sort(nodeSet, comparator);
		return nodeSet;
	}
	

	/**
	 *  condense strongly connected component to be a node
	*/
	public cg_graph sccDAG(){
		StrongConnectivityInspector<String, edge> sccIns = new StrongConnectivityInspector<String, edge>(this);
		List<Set<String>> sccsets = sccIns.stronglyConnectedSets();
		cg_graph sccDAG = new cg_graph();

		HashMap<String, String> clusterMap = new HashMap<String, String>();
		//		int i = 0;
		for(Set<String> s:sccsets){
			String newnode = new String();
			String newtag = "";
			for(String n:s){
				newtag = newtag+n+"_";
			}
			newtag = newtag.substring(0,newtag.lastIndexOf("_"));
			/**
			 * where there is a very large scc, use below two lines to label the node, to avoid the long node id.
			 */
			//			newtag = String.valueOf(i);
			//			i++;
			for(String n:s){
				clusterMap.put(n, newtag);
			}
			newnode = newtag;
			sccDAG.addVertex(newnode);
		}
		for(Set<String> scc:sccsets){
			for(String n:scc){
				String newfrom = clusterMap.get(n);
				if(this.outDegreeOf(n)>0){
					for(edge e:this.outgoingEdgesOf(n)){
						String end = this.getEdgeTarget(e);
						if(!scc.contains(end)){	// get the node outside the current cluster
							String newend = clusterMap.get(end);							
							if(!sccDAG.containsEdge(newfrom, newend)){
								edge newedge = new edge(newfrom,newend);
								sccDAG.addEdge(newfrom, newend, newedge);
							}
						}
					}
				}
			}
		}
		return sccDAG;
	}

	
	/**
	 * @return a set of strongly connected components
	 */
	public List<Set<String>> sccSet(){
		StrongConnectivityInspector<String, edge> sccIns = new StrongConnectivityInspector<String, edge>(this);
		List<Set<String>> sccsets = sccIns.stronglyConnectedSets();
		return sccsets;
	}
	
	

	
	/**
	 * this procedure computes topological rank of the graph
	 */
	public HashMap<String, Integer> topRank(){
		cg_graph DAGP = this.sccDAG();
		Stack<String> s = new Stack<String>();
		HashMap<String, Integer> visited = new HashMap<String, Integer>();

		String virtualvertex = "v";
		DAGP.addVertex(virtualvertex);
		for(String v:DAGP.vertexSet()){
			if(!v.equals(virtualvertex)){
				if(DAGP.inDegreeOf(v)==0){
					edge ne = new edge(virtualvertex, v);
					DAGP.addEdge(virtualvertex, v, ne);
				}
			}
		}

		int max = 0;
		boolean flag = true;
		s.add(virtualvertex);

		while(!s.isEmpty()){
			String current = s.peek();	//	remains the node in the stack until its rank is evaluated.
			flag = true;
			max = 0;
			for(edge e:DAGP.outgoingEdgesOf(current)){
				String n = (String) e.getTarget();
				if(!visited.keySet().contains(n)){
					s.add(n);
					flag = false;
				}
				else if(visited.keySet().contains(n) && flag){
					if(max<visited.get(n)){
						max = visited.get(n);
					}
				}
			}
			if(flag == true){
				visited.put(current, max+1);
				s.remove(current);
			}
		}

		// for each node in scc, assign its rank
		visited.remove(virtualvertex);
		HashMap<String, Integer> toprank = new HashMap<String, Integer>();
		for(String hv:visited.keySet()){
			String[] scc = hv.split("_");
			int rank = visited.get(hv);
			if(scc.length>1){
				for(String v:scc){
					toprank.put(v, rank);
				}
			}
			else
				toprank.put(hv, rank);
		}
		return toprank;
	}
}
