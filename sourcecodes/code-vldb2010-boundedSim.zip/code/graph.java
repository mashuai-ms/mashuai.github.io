/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Graph;

import java.io.Serializable;
import java.util.HashMap;

/**
 *  THIS class integrates graph and its attribute
 *  When initialise the graph, should also correctly set currentid.
 * @author s0944873
 */
public class graph implements Serializable{
    
    private cg_graph G;
    private HashMap<String, String> gattr;
    private int currentid;      //  this variable is used for recording the maximum id, mostly used when updating the graph
    
    public graph(){
        this.currentid = 0;
    }
    
    public graph(cg_graph graph, HashMap<String, String> attribute){
       this.G = graph;
       this.gattr = attribute;
       this.currentid = graph.vertexSet().size();
    }

    public void setGraph(cg_graph graph){
        this.G = graph;
    }
    
    public cg_graph getGraph(){
        return this.G;
    }
    
    public void setAttribute(HashMap<String, String> attribute){
        this.gattr = attribute;
    }
    
    public HashMap<String, String> getAttribute(){
        return this.gattr;
    }
    
    public void setcurrentID(int id){
        this.currentid = id;
    }
    
    public int getcurrentID(){
        return this.currentid;
    }
}
